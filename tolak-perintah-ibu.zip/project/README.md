# Bagaimana Jika Kamu Menolak Semua Perintah Ibu? (Remotion)

Video komedi 2D vertikal 1080x1920, 30 fps, 2550 frame (~85 detik). Tanpa header/judul/nomor scene; hanya adegan dan subtitle bawah.

## STATUS JUJUR (baca dulu)
- **Belum pernah dirender menjadi MP4** oleh pembuat proyek ini (lingkungan tanpa internet, tidak bisa `npm install`). Frame-frame kunci sudah dipratinjau lewat stub Remotion + Chromium, dan TypeScript dicek terhadap stub tipe. Kamu perlu menjalankan `npm run dev` dan `npm run render` sendiri. Jika ada galat versi, jalankan `npx remotion upgrade`.
- **`public/narasi.mp3` belum ada.** Subtitle dan timing beat adalah **PERKIRAAN dari SRT**, belum tersinkron dengan audio asli.
- SFX dan musik di `public/sounds/` adalah **placeholder sintetis** (dibuat `tools/make_sounds.py`). Ganti dengan SFX pilihanmu (nama file sama).

## Memasang narasi
1. Taruh audio di `public/narasi.mp3`.
2. Buka `src/data/config.ts`, ubah `HAS_NARASI = true`.
3. Jika subtitle bergeser, atur `AUDIO_OFFSET` (detik). Jika durasi audio berbeda, ubah `TOTAL_FRAMES` dan durasi beat di `src/data/beats.ts` (+ frame SFX di `SoundEffects.tsx`).

## Struktur
- `src/data/` : `config.ts` (fps, offset), `beats.ts` (6 beat), `layout.ts` (koordinat), `captions.ts` (subtitle, kata penting kuning)
- `src/components/` : rig karakter (`Character`, `MainCharacter`, `MotherCharacter`, `CharacterExpressions`), latar, pencahayaan, properti, efek, kamera, subtitle, SFX
- `src/beats/` : `Beat01`..`Beat06`
- `public/narasi.srt` : SRT acuan (provisional)

## Tutorial Windows
1. Instal Node.js LTS dari nodejs.org.
2. Ekstrak ZIP.
3. Buka folder proyek, klik kolom alamat, ketik `cmd`, Enter.
4. `npm install`
5. `npm run dev` (preview Remotion Studio di browser)
6. `npm run render`
7. Hasil: `out/video.mp4`

## Android
Remotion butuh Node.js dan Chromium, jadi tidak jalan native di Android. Alternatif: pakai komputer/laptop, atau lingkungan cloud (GitHub Codespaces, Gitpod) lalu unduh MP4-nya.
