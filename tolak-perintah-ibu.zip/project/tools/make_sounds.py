"""Membuat SFX + musik latar sintetis (placeholder) ke public/sounds/*.wav.
Jalankan: python3 tools/make_sounds.py   (butuh numpy). Ganti file dengan SFX pilihanmu kapan saja."""
import wave, os
import numpy as np

SR = 44100
rng = np.random.RandomState(7)
OUT = os.path.join(os.path.dirname(__file__), '..', 'public', 'sounds')
os.makedirs(OUT, exist_ok=True)

def T(d): return np.arange(int(SR * d)) / SR
def lp(x, a):
    y = np.zeros_like(x); s = 0.0
    for i, v in enumerate(x):
        s += (v - s) * (a if np.isscalar(a) else a[i]); y[i] = s
    return y
def hp(x, a): return x - lp(x, a)
def noise(d): return rng.uniform(-1, 1, int(SR * d))
def dec(t, k): return np.exp(-t * k)
def hann(n): return np.hanning(n)
def place(buf, snd, at):
    i = int(at * SR); buf[i:i + len(snd)] += snd[:len(buf) - i]; return buf
def save(name, x):
    x = x / (np.max(np.abs(x)) + 1e-9) * 0.9
    with wave.open(os.path.join(OUT, name + '.wav'), 'wb') as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR)
        w.writeframes((x * 32767).astype('<i2').tobytes())

def pop():
    t = T(0.14); return np.sin(2 * np.pi * (500 + 900 * t / 0.14) * t) * dec(t, 28)
def whoosh():
    n = noise(0.5); a = np.linspace(0.02, 0.35, len(n)); a = np.minimum(a, 0.35)
    return lp(n, a) * hann(len(n)) * 1.5
def alarm():
    t = T(2.0); gate = ((t % 0.5) < 0.12) | (((t % 0.5) > 0.2) & ((t % 0.5) < 0.32))
    return np.sign(np.sin(2 * np.pi * 1000 * t)) * 0.5 * gate
def bedsheet(): n = noise(0.35); return lp(n, 0.12) * hann(len(n)) * 1.4
def steps():
    b = np.zeros(int(SR * 1.2))
    for k in range(4):
        t = T(0.15); b = place(b, (np.sin(2 * np.pi * 110 * t) + 0.4 * noise(0.15)) * dec(t, 30), k * 0.3)
    return b
def sweep():
    b = np.zeros(int(SR * 0.8))
    for k in range(2):
        n = noise(0.35); b = place(b, hp(lp(n, 0.4), 0.03) * hann(len(n)) * 2, k * 0.38)
    return b
def plates():
    b = np.zeros(int(SR * 0.9))
    for at in (0, 0.14, 0.31):
        t = T(0.5); s = sum(np.sin(2 * np.pi * f * t) for f in (2100, 3300, 4700)) * dec(t, 9)
        b = place(b, s * 0.4, at)
    return b
def cloth(): n = noise(0.4); return lp(n, 0.05) * dec(T(0.4), 8) * 3
def growl():
    t = T(1.2); f = 80 + 25 * np.sin(2 * np.pi * 7 * t)
    return np.sign(np.sin(np.cumsum(2 * np.pi * f / SR))) * (0.6 + 0.4 * np.sin(2 * np.pi * 5 * t)) * hann(len(t)) * 0.7
def sizzle():
    n = noise(2.0); return hp(n, 0.2) * (0.5 + 0.5 * (rng.uniform(0, 1, len(n)) > 0.6)) * hann(len(n)) ** 0.3
def fire():
    n = noise(1.2); imp = (rng.uniform(0, 1, len(n)) > 0.9995) * rng.uniform(-1, 1, len(n)) * 3
    return (lp(n, 0.08) * 1.2 + lp(imp, 0.5)) * hann(len(n))
def paper():
    n = noise(0.9); return hp(n, 0.1) * (0.6 + 0.4 * np.sin(2 * np.pi * 14 * T(0.9))) * hann(len(n)) * 0.8
def reveal():
    t = T(1.5); s = sum(np.sin(2 * np.pi * f * t * (1 + 0.1 * t)) for f in (261.6, 329.6, 392.0)); return s * np.minimum(t * 3, 1) * dec(t, 1.2)
def shock():
    t = T(0.7); f = 1200 * np.exp(-t * 3.2) + 150
    return np.sign(np.sin(np.cumsum(2 * np.pi * f / SR))) * 0.5 * dec(t, 3)
def impact():
    t = T(0.5); return (np.sin(2 * np.pi * 70 * t) + 0.5 * noise(0.5)) * dec(t, 10)
def sting():
    b = np.zeros(int(SR * 1.0))
    for at, f in ((0, 392.0), (0.18, 196.0)):
        t = T(0.5); b = place(b, np.sin(2 * np.pi * f * t) * 0.6 + 0.3 * np.sign(np.sin(2 * np.pi * f * t)), at)
        b[int(at * SR):int(at * SR) + len(t)] *= dec(t, 5)[:len(b) - int(at * SR)] if False else 1
    return b * dec(T(1.0), 3)
def piano():
    b = np.zeros(int(SR * 3.0))
    for k, f in enumerate((220.0, 261.6, 329.6, 440.0)):
        t = T(2.0); s = (np.sin(2 * np.pi * f * t) + 0.3 * np.sin(4 * np.pi * f * t)) * dec(t, 2.2); b = place(b, s, k * 0.5)
    return b
def bounce():
    t = T(0.5); return np.sin(2 * np.pi * (260 + 60 * np.sin(2 * np.pi * 14 * t)) * t) * dec(t, 7)
def frustration():
    t = T(0.6); f = 260 - 100 * t / 0.6
    return lp(np.sign(np.sin(np.cumsum(2 * np.pi * f / SR))), 0.08) * hann(len(t)) * 1.5
def refuse():
    b = np.zeros(int(SR * 0.45))
    for at, f in ((0, 320.0), (0.2, 250.0)):
        t = T(0.15); b = place(b, np.sin(2 * np.pi * f * t) * dec(t, 14), at)
    return b
def sweat(): t = T(0.3); return np.sin(2 * np.pi * (1500 - 900 * t / 0.3) * t) * dec(t, 18)

def music():
    bpm = 120; beat = 60 / bpm; bars = 8; total = bars * 4 * beat
    b = np.zeros(int(SR * total))
    chords = [(65.4, (261.6, 329.6, 392.0)), (98.0, (246.9, 293.7, 392.0)), (110.0, (261.6, 329.6, 440.0)), (87.3, (261.6, 349.2, 440.0))]
    for bar in range(bars):
        root, tones = chords[bar % 4]
        for q in range(4):
            at = (bar * 4 + q) * beat
            t = T(0.4); b = place(b, np.sin(2 * np.pi * root * t) * dec(t, 7) * 0.9, at)
            t = T(0.15); b = place(b, np.sin(2 * np.pi * 55 * t * (1 + 2 * dec(t, 40))) * dec(t, 25) * 0.8 if q % 2 == 0 else np.zeros(len(t)), at)
            for e in range(2):
                f = tones[(q * 2 + e) % 3] * (2 if (q + e) % 2 else 1)
                t = T(0.3); s = (np.sin(2 * np.pi * f * t) + 0.25 * np.sin(4 * np.pi * f * t)) * dec(t, 9)
                b = place(b, s * 0.35, at + e * beat / 2)
            n = noise(0.04); b = place(b, hp(n, 0.3) * dec(T(0.04), 70) * 0.25, at + beat / 2)
    return b

for name, fn in dict(pop=pop, whoosh=whoosh, alarm=alarm, bedsheet=bedsheet, steps=steps, sweep=sweep, plates=plates,
                     cloth=cloth, growl=growl, sizzle=sizzle, fire=fire, paper=paper, reveal=reveal, shock=shock,
                     impact=impact, sting=sting, piano=piano, bounce=bounce, frustration=frustration, refuse=refuse,
                     sweat=sweat, music=music).items():
    save(name, fn()); print('ok', name)
