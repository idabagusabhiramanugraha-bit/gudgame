import React from 'react';
import {Character, CharProps} from './Character';

/** Karakter ibu: rambut sanggul, blus krem, apron merah marun. */
export const MotherCharacter: React.FC<Omit<CharProps, 'who'>> = (props) => <Character who="mom" {...props} />;
