import React from 'react';
import {interpolate} from 'remotion';
import {C} from '../data/config';

/** Sinar sunburst kartun di belakang adegan (koordinat dunia). */
export const Sunburst: React.FC<{cx: number; cy: number; rot: number; c1: string; c2: string; n?: number}> = ({cx, cy, rot, c1, c2, n = 18}) => {
  const rays: React.ReactNode[] = [];
  const R = 2600;
  for (let i = 0; i < n; i++) {
    const a0 = ((i * 2) / (n * 2)) * Math.PI * 2 + (rot * Math.PI) / 180;
    const a1 = a0 + Math.PI / n;
    rays.push(<path key={i} d={`M ${cx} ${cy} L ${cx + Math.cos(a0) * R} ${cy + Math.sin(a0) * R} L ${cx + Math.cos(a1) * R} ${cy + Math.sin(a1) * R} Z`} fill={c2} />);
  }
  return (
    <g>
      <rect x={-300} y={0} width={1680} height={1920} fill={c1} />
      {rays}
    </g>
  );
};

export const SpeedLines: React.FC<{cx: number; cy: number; frame: number; color?: string; n?: number; inner?: number}> = ({cx, cy, frame, color = C.ink, n = 22, inner = 360}) => (
  <g stroke={color} strokeWidth={5} strokeLinecap="round" opacity={0.55}>
    {Array.from({length: n}).map((_, i) => {
      const a = (i / n) * Math.PI * 2 + (frame % 3) * 0.02;
      const r0 = inner + ((i * 37) % 60);
      const r1 = r0 + 90 + ((i * 53) % 90);
      return <line key={i} x1={cx + Math.cos(a) * r0} y1={cy + Math.sin(a) * r0} x2={cx + Math.cos(a) * r1} y2={cy + Math.sin(a) * r1} />;
    })}
  </g>
);

export const ImpactBurst: React.FC<{x: number; y: number; frame: number; start: number; color?: string; size?: number}> = ({x, y, frame, start, color = C.yellow, size = 260}) => {
  const t = frame - start;
  if (t < 0 || t > 14) return null;
  const k = interpolate(t, [0, 3, 14], [0.2, 1.1, 1.5], {extrapolateRight: 'clamp'});
  const o = interpolate(t, [0, 10, 14], [1, 0.9, 0], {extrapolateRight: 'clamp'});
  const pts: string[] = [];
  for (let i = 0; i < 16; i++) {
    const r = i % 2 === 0 ? size : size * 0.5;
    const a = (i / 16) * Math.PI * 2;
    pts.push(`${x + Math.cos(a) * r * k},${y + Math.sin(a) * r * k}`);
  }
  return <polygon points={pts.join(' ')} fill={color} stroke={C.ink} strokeWidth={8} strokeLinejoin="round" opacity={o} />;
};

export const Sparkle: React.FC<{x: number; y: number; s?: number; color?: string}> = ({x, y, s = 1, color = C.yellow}) => (
  <path transform={`translate(${x} ${y}) scale(${s})`} d="M 0 -40 Q 6 -6 40 0 Q 6 6 0 40 Q -6 6 -40 0 Q -6 -6 0 -40 Z" fill={color} stroke={C.ink} strokeWidth={4} />
);

export const XMark: React.FC<{x: number; y: number; frame: number; start: number; s?: number}> = ({x, y, frame, start, s = 1}) => {
  const t = frame - start;
  if (t < 0) return null;
  const k = interpolate(t, [0, 4, 8], [0, 1.3, 1], {extrapolateRight: 'clamp'});
  return (
    <g transform={`translate(${x} ${y}) scale(${k * s})`} stroke={C.red} strokeWidth={26} strokeLinecap="round">
      <line x1={-40} y1={-40} x2={40} y2={40} />
      <line x1={40} y1={-40} x2={-40} y2={40} />
    </g>
  );
};

export const Smoke: React.FC<{x: number; y: number; frame: number; n?: number; color?: string}> = ({x, y, frame, n = 6, color = '#5a5a63'}) => (
  <g>
    {Array.from({length: n}).map((_, i) => {
      const t = ((frame * 1.4 + i * 22) % 120) / 120;
      return <circle key={i} cx={x + Math.sin(i * 2.1 + frame * 0.08) * 40 + (i - n / 2) * 12} cy={y - t * 260} r={26 + t * 60} fill={color} stroke={C.ink} strokeWidth={5} opacity={0.85 * (1 - t)} />;
    })}
  </g>
);

export const Flame: React.FC<{x: number; y: number; frame: number; s?: number}> = ({x, y, frame, s = 1}) => {
  const w = Math.sin(frame * 0.7) * 0.12;
  return (
    <g transform={`translate(${x} ${y}) scale(${s * (1 + w)} ${s * (1 - w)})`}>
      <path d="M 0 0 C -60 -30 -50 -110 -10 -150 C -10 -100 20 -100 20 -150 C 70 -100 70 -20 0 0 Z" fill="#FF7A1A" stroke={C.ink} strokeWidth={6} strokeLinejoin="round" />
      <path d="M 0 -4 C -28 -20 -22 -60 0 -84 C 22 -56 30 -20 0 -4 Z" fill={C.yellow} />
    </g>
  );
};

export const Spiral: React.FC<{x: number; y: number; frame: number; s?: number}> = ({x, y, frame, s = 1}) => (
  <path
    transform={`translate(${x} ${y}) rotate(${frame * 10}) scale(${s})`}
    d="M 0 0 C 14 -2 18 12 4 18 C -16 24 -30 0 -18 -22 C -2 -44 34 -34 40 -4 C 44 30 12 50 -22 44"
    fill="none" stroke={C.ink} strokeWidth={6} strokeLinecap="round"
  />
);

export const Note: React.FC<{x: number; y: number; frame: number}> = ({x, y, frame}) => (
  <g transform={`translate(${x} ${y + Math.sin(frame * 0.15) * 10}) rotate(${Math.sin(frame * 0.12) * 10})`}>
    <ellipse cx={0} cy={0} rx={18} ry={13} fill={C.ink} />
    <line x1={16} y1={0} x2={16} y2={-70} stroke={C.ink} strokeWidth={7} strokeLinecap="round" />
    <path d="M 16 -70 Q 46 -56 40 -30" fill="none" stroke={C.ink} strokeWidth={7} strokeLinecap="round" />
  </g>
);

export const Drop: React.FC<{x: number; y: number; frame: number}> = ({x, y, frame}) => (
  <path transform={`translate(${x} ${y + (frame % 24) * 1.5})`} d="M 0 -30 Q 22 6 0 22 Q -22 6 0 -30 Z" fill="#6EC6FF" stroke={C.ink} strokeWidth={4} />
);
