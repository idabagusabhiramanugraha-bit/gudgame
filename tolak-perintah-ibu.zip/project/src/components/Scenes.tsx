import React from 'react';
import {Easing, interpolate} from 'remotion';
import {C} from '../data/config';
import {LAYOUT, place} from '../data/layout';
import {MainCharacter} from './MainCharacter';
import {MotherCharacter} from './MotherCharacter';
import {POSES, Pose, handPos, mkPose, poseAt, walkPose} from './Character';
import {BedroomBackground, HouseWideBackground, KitchenBackground, LivingRoomBackground} from './Backgrounds';
import {AfternoonLighting, DullLighting, MorningLighting, NightLighting, NoonLighting} from './Lighting';
import {Basket, Bed, Bill, Broom, ClothesPile, DigitalClock, Glass, Pan, Plate, PlateStack, Pot, Sofa, Spatula, ThoughtBubble, WallClock, Bowl, Shower, SpeechBubble} from './Props';
import {Drop, Flame, Note, Smoke, Sparkle, XMark} from './Effects';

const cl = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;
const lerp = (f: number, a: number, b: number, x0: number, x1: number, easing?: (t: number) => number) =>
  interpolate(f, [a, b], [x0, x1], {...cl, easing});
const back = Easing.out(Easing.back(1.6));
const st = {stroke: C.ink, strokeWidth: 6, strokeLinejoin: 'round' as const};

/* ------------------------------------------------------------------ BED */
export const BedScene: React.FC<{frame: number; phase: 'shout' | 'shake'}> = ({frame, phase}) => {
  const kid = place(LAYOUT.b02.kidSleep, 'lying');
  const mom = place(LAYOUT.b02.mom);
  const shake = phase === 'shake';
  const cover = shake ? lerp(frame, 14, 20, 0, 1) : 0;
  const jig = shake && frame < 14 ? Math.sin(frame * 1.7) * 3 : 0;
  const r = 500 + 190 * cover;
  const t = 1040 - 78 * cover;
  const momPose: Pose = shake
    ? mkPose({aL: [30, 20], aR: [30, 20], lean: -16 + Math.sin(frame * 1.7) * 4, tilt: -6})
    : poseAt(frame, [
        {f: 0, pose: POSES.hips},
        {f: 14, pose: mkPose({aL: [60, -30], aR: [60, -30], lean: -8})},
        {f: 40, pose: mkPose({aL: [70, -20], aR: [70, -20], lean: -10})},
      ]);
  return (
    <g>
      <BedroomBackground />
      <DigitalClock x={790} y={798} s={0.55} text="06:00" frame={frame} />
      <MotherCharacter {...mom} flip pose={momPose} expr={shake && frame > 22 ? 'angry' : 'shouting'} frame={frame} />
      {!shake && (
        <g stroke={C.ink} strokeWidth={7} strokeLinecap="round" fill="none">
          <path d="M 610 600 q -50 -10 -80 -40" /><path d="M 604 640 q -60 0 -90 0" /><path d="M 610 680 q -50 10 -80 40" />
        </g>
      )}
      <Bed x={60} y={1330} layer="back" />
      <MainCharacter {...kid} cy={kid.cy - 10} cx={kid.cx + 30} rot={90 + jig} pose={POSES.idle} expr="sleepy" frame={frame} shadow={false} />
      <path d={`M 130 1228 Q 130 1062 230 ${t + 10} L ${r - 60} ${t} Q ${r} ${t + 24} ${r} 1228 Z`} fill="#E58A9B" {...st} />
      <path d={`M 190 1226 L 200 ${t + 40} M 270 1226 L 280 ${t + 26} M 350 1226 L 360 ${t + 14}`} stroke="#C96A80" strokeWidth={8} fill="none" strokeLinecap="round" />
      {cover > 0.5 && <path d={`M ${r - 120} ${t + 4} L ${r - 112} ${t - 40} L ${r - 86} ${t - 6} L ${r - 74} ${t - 52} L ${r - 52} ${t - 2} L ${r - 36} ${t - 36} L ${r - 30} ${t + 8} Z`} fill={C.hair} {...st} />}
      <Bed x={60} y={1330} layer="front" />
      <MorningLighting />
    </g>
  );
};

/* ------------------------------------------------------------ REFUSAL */
export const RefusalScene: React.FC<{frame: number; kind: 'broom' | 'dishes' | 'warung'}> = ({frame, kind}) => {
  const mom = place(LAYOUT.b03.mom);
  const kid = place(LAYOUT.b03.kid);
  const clock = <WallClock x={230} y={420} hour={12} />;
  if (kind === 'broom') {
    const step = lerp(frame, 18, 30, 0, 50);
    const sweepA = Math.sin(frame * 0.5) * 8;
    const momPose = mkPose({aL: [42, -112], aR: [70 + sweepA, -10], lean: 5});
    const kidPose =
      frame < 75
        ? POSES.fold
        : mkPose({aL: [85 + Math.sin(frame * 0.9) * 12, 85], aR: [85 - Math.sin(frame * 0.9) * 12, 85], lean: -4});
    return (
      <g>
        <LivingRoomBackground />
        {clock}
        <MotherCharacter {...mom} pose={momPose} expr={frame < 60 ? 'shouting' : 'angry'} frame={frame} holdR={<Broom />} upright />
        <g opacity={0.6}>
          {[0, 1, 2].map((i) => (
            <circle key={i} cx={470 + i * 40 + Math.sin(frame * 0.5 + i) * 10} cy={1300 - ((frame * 2 + i * 12) % 40)} r={14 + i * 4} fill="#E8DDC8" stroke={C.ink} strokeWidth={3} />
          ))}
        </g>
        <MainCharacter {...kid} cx={kid.cx + step} pose={kidPose} expr={frame < 75 ? 'smug' : 'annoyed'} frame={frame} />
        <XMark x={800 + step} y={600} frame={frame} start={100} />
        <NoonLighting />
      </g>
    );
  }
  if (kind === 'dishes') {
    const momPose = mkPose({aL: [42, -112], aR: [88, 4], lean: 4});
    const kidPose = mkPose({aL: [30, -100], aR: [85 + Math.sin(frame * 0.8) * 20, 85], tilt: 10, lean: -3});
    return (
      <g>
        <KitchenBackground />
        <PlateStack x={400} y={942} n={9} sway={2} />
        <PlateStack x={560} y={946} n={6} />
        <Glass x={640} y={944} tilt={10} />
        <MotherCharacter {...mom} cx={mom.cx - 20} pose={momPose} expr={frame < 40 ? 'shouting' : 'annoyed'} frame={frame} />
        <MainCharacter {...kid} cx={kid.cx - 20} pose={kidPose} expr="ignoring" look={14} frame={frame} />
        <XMark x={780} y={600} frame={frame} start={45} />
        <NoonLighting />
      </g>
    );
  }
  // warung
  const step = lerp(frame, 55, 78, 0, 80);
  const momPose = mkPose({aL: [30, -60], aR: [88, 4], lean: 4});
  const kidPose = mkPose({aL: [85, 85], aR: [85, 85], tilt: Math.sin(frame * 0.55) * 9});
  return (
    <g>
      <LivingRoomBackground />
      {clock}
      <MotherCharacter {...mom} cx={190} pose={momPose} expr={frame < 40 ? 'shouting' : 'annoyed'} frame={frame} holdL={<Bill x={0} y={0} s={0.9} />} upright />
      <MainCharacter {...kid} cx={610 + step} pose={kidPose} expr="annoyed" frame={frame} />
      <XMark x={610 + step} y={620} frame={frame} start={35} />
      <NoonLighting />
    </g>
  );
};

export const CleaningScene: React.FC<{frame: number}> = ({frame}) => <RefusalScene frame={frame} kind="broom" />;

/* -------------------------------------------------------------- SOFA */
export const SofaTriumph: React.FC<{frame: number}> = ({frame}) => {
  const drop = lerp(frame, 0, 22, -380, 0, back);
  const land = frame >= 22 && frame < 34 ? Math.sin(((frame - 22) / 12) * Math.PI) : 0;
  const pose = mkPose({aL: [110, 120], aR: [110, 120], lL: [34, 30], lR: [100, -50], bob: 0});
  return (
    <g>
      <LivingRoomBackground />
      <Sofa x={540} y={1330} layer="back" />
      <MainCharacter cx={540} cy={1096 + drop} s={0.8} sy={1 - land * 0.06} sx={1 + land * 0.05} pose={pose} expr={frame < 40 ? 'smug' : 'laughing'} frame={frame} shadow={false} />
      <g transform={`translate(0 ${land * 8})`}><Sofa x={540} y={1330} layer="front" /></g>
      {frame > 30 && <Note x={260} y={940} frame={frame} />}
      {frame > 50 && <Sparkle x={820} y={900} s={0.9} />}
      <NoonLighting />
    </g>
  );
};

/* ------------------------------------------------------- MESSY HOUSE */
export const MessyHouseScene: React.FC<{frame: number}> = ({frame}) => {
  const fall = (t0: number, x: number, color: number) => {
    const t = frame - t0;
    if (t < 0) return null;
    const y = Math.min(1100 + 0.5 * 0.55 * t * t, 1440);
    return <g transform={`translate(${x} ${y}) rotate(${t * 6})`}><ClothesPile x={0} y={0} s={0.6} n={1 + color} /></g>;
  };
  const look = Math.sin(frame * 0.12) * 12;
  const kidPose = mkPose({aL: [110, 120], aR: [110, 120], lL: [34, 30], lR: [70, -60]});
  const kidExpr = frame < 100 ? 'smug' : frame < 170 ? 'confused' : 'nervous';
  return (
    <g>
      <HouseWideBackground />
      {/* dapur: piring dan gelas menumpuk */}
      <PlateStack x={20} y={946} n={13} sway={3} />
      <PlateStack x={130} y={946} n={9} sway={-2} />
      <Glass x={220} y={944} tilt={14} /><Glass x={262} y={946} tilt={-18} />
      <Pot x={330} y={946} />
      <Plate x={80} y={1420} /><Plate x={150} y={1450} /><Glass x={-120} y={1470} tilt={80} />
      {/* ruang keluarga */}
      <WallClock x={820} y={300} hour={4} />
      <Sofa x={640} y={1330} s={0.62} layer="back" />
      <MainCharacter cx={640} cy={1178} s={0.5} pose={kidPose} expr={kidExpr} look={look} frame={frame} shadow={false} />
      <Sofa x={640} y={1330} s={0.62} layer="front" />
      <ClothesPile x={500} y={1450} n={6} /><ClothesPile x={790} y={1480} n={5} /><ClothesPile x={150} y={1500} n={4} />
      <MotherCharacter cx={340} cy={1180} s={0.55} flip pose={POSES.fold} expr="silent" frame={frame} />
      {/* kamar */}
      <Bed x={930} y={1260} s={0.7} layer="back" messy />
      <Bed x={930} y={1260} s={0.7} layer="front" messy />
      <Basket x={1000} y={1290} s={0.8} overflow />
      {fall(70, 1010, 0)}{fall(125, 960, 1)}{fall(165, 1040, 2)}
      <ClothesPile x={1180} y={1480} n={6} /><ClothesPile x={1290} y={1420} n={4} />
      <path d="M 960 1000 q 14 -30 0 -60 q -14 -30 0 -60" fill="none" stroke="#6b8f3f" strokeWidth={6} strokeLinecap="round" opacity={0.7} />
      <AfternoonLighting />
    </g>
  );
};

/* ---------------------------------------------------------- COOKING */
export const CookingScene: React.FC<{frame: number}> = ({frame}) => {
  const k = Math.sin(frame * 0.6);
  const pose = mkPose({aL: [125 + k * 25, 40], aR: [60 + k * 6, -20], lL: [16, 0], lR: [16, 0], lean: k * 5, tilt: k * 4, bob: -Math.abs(k) * 6});
  const kid = {who: 'kid' as const, cx: 380, cy: 960, s: 1.1, pose};
  const [hx, hy] = handPos(kid, 'R');
  const px = hx + 160 * 1.1;
  const flameS = lerp(frame, 40, 80, 0, 1.4);
  const expr = frame < 40 ? 'confused' : frame < 110 ? 'scared' : 'shocked';
  const food = (t0: number, vx: number, vy: number, color: string, rx: number) => {
    const t = frame - t0;
    if (t < 0 || t > 60) return null;
    return <ellipse cx={px + vx * t} cy={hy - 20 + vy * t + 0.5 * 0.9 * t * t} rx={rx} ry={rx * 0.8} fill={color} stroke={C.ink} strokeWidth={4} />;
  };
  return (
    <g>
      <KitchenBackground night />
      <MotherCharacter cx={1010} cy={1010} s={0.8} flip pose={POSES.fold} expr="silent" frame={frame} />
      <MainCharacter {...kid} expr={expr} frame={frame} holdR={<Pan tilt={-90} />} holdL={<Spatula rotate={180} />} upright />
      {frame > 20 && <Smoke x={px} y={hy - 30} frame={frame} />}
      {frame > 40 && <Flame x={px} y={hy - 12} frame={frame} s={flameS} />}
      {food(50, 4, -9, C.red, 22)}{food(70, -3, -11, '#fff', 18)}{food(90, 6, -10, '#F29E4C', 20)}
      <ellipse cx={330} cy={1450} rx={80} ry={20} fill="#F2F2F2" stroke={C.ink} strokeWidth={5} opacity={frame > 120 ? 1 : 0} />
      <NightLighting glowX={520} glowY={260} />
    </g>
  );
};

/* ----------------------------------------------------------- MEMORY */
const MiniMom: React.FC<{cx: number; cy: number; frame: number; kind: number}> = ({cx, cy, frame, kind}) => {
  const sw = Math.sin(frame * 0.4);
  const pose = [
    mkPose({aL: [42, -112], aR: [70 + sw * 10, -10], lean: 3 + sw * 3}),
    mkPose({aL: [40, -60], aR: [40, -60]}),
    mkPose({aL: [42, -112], aR: [60 + sw * 8, -40]}),
    mkPose({aL: [30, -70], aR: [30 - sw * 12, -70]}),
  ][kind];
  const hold = [<Broom key="b" />, null, <Spatula key="s" />, null][kind];
  return <MotherCharacter cx={cx} cy={cy} s={0.28} pose={pose} expr="neutral" frame={frame} holdR={hold} upright={kind === 0} />;
};

export const MemoryScene: React.FC<{frame: number}> = ({frame}) => {
  const kidPose = mkPose({aL: [6, 8], aR: [6, 8], lean: 14, tilt: 10});
  const pos: [number, number][] = [[60, 230], [580, 230], [60, 480], [580, 480]];
  const t0 = [10, 35, 60, 85];
  const veil = lerp(frame, 0, 40, 0.35, 0.12);
  return (
    <g>
      <KitchenBackground night />
      <rect x={-300} y={0} width={1680} height={1920} fill="#1d1450" opacity={veil} />
      <NightLighting glowX={520} glowY={260} />
      <MainCharacter cx={540} cy={1010} s={0.8} pose={kidPose} expr={frame < 100 ? 'regretful' : 'crying'} frame={frame} />
      {pos.map(([x, y], i) => {
        const t = frame - t0[i];
        if (t < 0) return null;
        const k = lerp(t, 0, 10, 0, 1, back);
        const bob = Math.sin((frame + i * 9) * 0.1) * 5;
        return (
          <g key={i} transform={`translate(0 ${bob})`}>
            <ThoughtBubble x={x + 220 * (1 - k)} y={y + 115 * (1 - k)} w={440} h={230} s={k} tail={[x < 300 ? 260 : 180, 300]}>
              <g transform={`translate(0 0)`}>
                {i === 1 && <Basket x={320} y={200} s={0.5} />}
                {i === 1 && <path d="M 80 40 L 400 40" stroke={C.ink} strokeWidth={4} />}
                {i === 3 && <PlateStack x={330} y={205} n={5} />}
                {i === 2 && <Pot x={330} y={205} />}
                <MiniMom cx={150} cy={118} frame={frame} kind={i} />
              </g>
            </ThoughtBubble>
          </g>
        );
      })}
    </g>
  );
};

/* ------------------------------------------------- BEAT 03 EXTRAS */
export {NoonLighting, DullLighting, NightLighting, AfternoonLighting, MorningLighting};
export {Bowl, Shower, SpeechBubble, Drop, Bed, DigitalClock, BedroomBackground, LivingRoomBackground, KitchenBackground, walkPose};
