import React from 'react';
import {C} from '../data/config';

export type ExprName =
  | 'neutral' | 'annoyed' | 'angry' | 'smug' | 'lazy' | 'sleepy' | 'ignoring'
  | 'laughing' | 'happy' | 'confused' | 'surprised' | 'shocked' | 'nervous'
  | 'scared' | 'regretful' | 'crying' | 'exhausted' | 'shouting'
  | 'disappointed' | 'silent';

type EyeT = 'dot' | 'half' | 'round' | 'wide' | 'arc' | 'closed';
type MouthT = 'flat' | 'smile' | 'smirk' | 'frown' | 'open' | 'big' | 'shout' | 'oh' | 'wavy' | 'grit' | 'tiny';
type Extra = 'none' | 'sweat' | 'vein' | 'tear' | 'blush' | 'question' | 'exclaim' | 'zzz';

type Spec = {brow: [number, number, number]; eye: EyeT; mouth: MouthT; extra: Extra};

const EXPR: Record<ExprName, Spec> = {
  neutral: {brow: [0, 0, 0], eye: 'dot', mouth: 'flat', extra: 'none'},
  annoyed: {brow: [8, -8, 2], eye: 'half', mouth: 'flat', extra: 'none'},
  angry: {brow: [24, -24, 4], eye: 'dot', mouth: 'grit', extra: 'vein'},
  smug: {brow: [-10, 6, -2], eye: 'half', mouth: 'smirk', extra: 'none'},
  lazy: {brow: [0, 0, 6], eye: 'half', mouth: 'flat', extra: 'none'},
  sleepy: {brow: [0, 0, 8], eye: 'closed', mouth: 'tiny', extra: 'zzz'},
  ignoring: {brow: [6, -6, 0], eye: 'half', mouth: 'tiny', extra: 'none'},
  laughing: {brow: [-8, 8, -6], eye: 'arc', mouth: 'big', extra: 'none'},
  happy: {brow: [-6, 6, -4], eye: 'arc', mouth: 'smile', extra: 'blush'},
  confused: {brow: [-12, 10, -4], eye: 'dot', mouth: 'wavy', extra: 'question'},
  surprised: {brow: [0, 0, -24], eye: 'round', mouth: 'oh', extra: 'exclaim'},
  shocked: {brow: [0, 0, -30], eye: 'wide', mouth: 'open', extra: 'sweat'},
  nervous: {brow: [-16, 16, -4], eye: 'dot', mouth: 'wavy', extra: 'sweat'},
  scared: {brow: [-20, 20, -10], eye: 'round', mouth: 'open', extra: 'sweat'},
  regretful: {brow: [-20, 20, 4], eye: 'dot', mouth: 'frown', extra: 'none'},
  crying: {brow: [-22, 22, 4], eye: 'closed', mouth: 'frown', extra: 'tear'},
  exhausted: {brow: [-8, 8, 8], eye: 'half', mouth: 'wavy', extra: 'sweat'},
  shouting: {brow: [22, -22, 0], eye: 'dot', mouth: 'shout', extra: 'vein'},
  disappointed: {brow: [-10, 10, 4], eye: 'half', mouth: 'frown', extra: 'none'},
  silent: {brow: [2, -2, 2], eye: 'half', mouth: 'flat', extra: 'none'},
};

const EY = 192;
const LX = 152;
const RX = 248;

const Eye: React.FC<{x: number; type: EyeT; blink: boolean; look: number}> = ({x, type, blink, look}) => {
  const ink = C.ink;
  if (type === 'dot') {
    return blink ? (
      <line x1={x - 14} y1={EY} x2={x + 14} y2={EY} stroke={ink} strokeWidth={7} strokeLinecap="round" />
    ) : (
      <ellipse cx={x + look} cy={EY} rx={9} ry={12} fill={ink} />
    );
  }
  if (type === 'half') {
    return (
      <g>
        <ellipse cx={x + look} cy={EY + 2} rx={10} ry={12} fill={ink} />
        <rect x={x - 18} y={EY - 14} width={36} height={15} fill={C.white} />
        <line x1={x - 18} y1={EY + 1} x2={x + 18} y2={EY + 1} stroke={ink} strokeWidth={7} strokeLinecap="round" />
      </g>
    );
  }
  if (type === 'round' || type === 'wide') {
    const r = type === 'round' ? 26 : 33;
    const pr = type === 'round' ? 7 : 5;
    return (
      <g>
        <circle cx={x} cy={EY} r={r} fill={C.white} stroke={ink} strokeWidth={6} />
        <circle cx={x + look * 0.6} cy={EY + 2} r={pr} fill={ink} />
      </g>
    );
  }
  if (type === 'arc') {
    return <path d={`M ${x - 17} ${EY + 8} Q ${x} ${EY - 22} ${x + 17} ${EY + 8}`} fill="none" stroke={ink} strokeWidth={8} strokeLinecap="round" />;
  }
  return <line x1={x - 16} y1={EY + 2} x2={x + 16} y2={EY + 2} stroke={ink} strokeWidth={8} strokeLinecap="round" />;
};

const Mouth: React.FC<{type: MouthT}> = ({type}) => {
  const ink = C.ink;
  const sw = {stroke: ink, strokeWidth: 7, strokeLinecap: 'round' as const, fill: 'none'};
  switch (type) {
    case 'flat':
      return <line x1={170} y1={262} x2={230} y2={262} {...sw} />;
    case 'tiny':
      return <line x1={188} y1={264} x2={214} y2={264} {...sw} />;
    case 'smile':
      return <path d="M 160 252 Q 200 296 240 252" {...sw} />;
    case 'smirk':
      return <path d="M 162 264 Q 214 290 246 246" {...sw} />;
    case 'frown':
      return <path d="M 165 276 Q 200 244 235 276" {...sw} />;
    case 'wavy':
      return <path d="M 156 266 q 11 -16 22 0 t 22 0 t 22 0 t 22 0" {...sw} />;
    case 'oh':
      return <ellipse cx={200} cy={268} rx={15} ry={20} fill="#8B1E1E" stroke={ink} strokeWidth={6} />;
    case 'open':
      return (
        <g>
          <ellipse cx={200} cy={272} rx={32} ry={28} fill="#8B1E1E" stroke={ink} strokeWidth={6} />
          <ellipse cx={200} cy={286} rx={18} ry={9} fill="#E8737A" />
        </g>
      );
    case 'shout':
      return (
        <g>
          <ellipse cx={200} cy={276} rx={44} ry={48} fill="#8B1E1E" stroke={ink} strokeWidth={7} />
          <ellipse cx={200} cy={300} rx={26} ry={13} fill="#E8737A" />
        </g>
      );
    case 'big':
      return (
        <g>
          <path d="M 146 244 Q 200 342 254 244 Z" fill="#8B1E1E" stroke={ink} strokeWidth={7} strokeLinejoin="round" />
          <ellipse cx={200} cy={296} rx={26} ry={13} fill="#E8737A" />
        </g>
      );
    case 'grit':
      return (
        <g>
          <rect x={156} y={248} width={88} height={36} rx={10} fill={C.white} stroke={ink} strokeWidth={6} />
          <line x1={186} y1={250} x2={186} y2={282} stroke={ink} strokeWidth={4} />
          <line x1={214} y1={250} x2={214} y2={282} stroke={ink} strokeWidth={4} />
          <line x1={158} y1={266} x2={242} y2={266} stroke={ink} strokeWidth={4} />
        </g>
      );
  }
};

const Extras: React.FC<{extra: Extra; frame: number}> = ({extra, frame}) => {
  const drip = (frame % 30) * 0.6;
  switch (extra) {
    case 'sweat':
      return (
        <g transform={`translate(0 ${drip})`}>
          <path d="M 318 128 Q 336 160 318 176 Q 300 160 318 128 Z" fill="#6EC6FF" stroke={C.ink} strokeWidth={4} />
        </g>
      );
    case 'vein':
      return (
        <g stroke={C.red} strokeWidth={7} fill="none" strokeLinecap="round" transform="translate(292 96)">
          <path d="M 0 10 Q 12 10 12 0" />
          <path d="M 28 10 Q 16 10 16 0" />
          <path d="M 0 26 Q 12 26 12 36" />
          <path d="M 28 26 Q 16 26 16 36" />
        </g>
      );
    case 'tear':
      return (
        <g fill="#6EC6FF" stroke={C.ink} strokeWidth={3}>
          <path d={`M 128 212 q -14 40 -2 ${70 + (frame % 20)} q 16 -20 2 -${70 + (frame % 20)} z`} />
          <path d={`M 272 212 q 14 40 2 ${70 + (frame % 20)} q -16 -20 -2 -${70 + (frame % 20)} z`} />
        </g>
      );
    case 'blush':
      return (
        <g fill="#FF8FA3" opacity={0.6}>
          <ellipse cx={124} cy={236} rx={20} ry={10} />
          <ellipse cx={276} cy={236} rx={20} ry={10} />
        </g>
      );
    case 'question':
      return <text x={300} y={130} fontSize={90} fontWeight={900} fill={C.ink} fontFamily="Arial Black, Arial, sans-serif">?</text>;
    case 'exclaim':
      return <text x={292} y={130} fontSize={96} fontWeight={900} fill={C.red} fontFamily="Arial Black, Arial, sans-serif">!</text>;
    case 'zzz':
      return (
        <g fontFamily="Arial Black, Arial, sans-serif" fontWeight={900} fill={C.ink}>
          <text x={290} y={110 - (frame % 40) * 0.5} fontSize={52}>z</text>
          <text x={324} y={70 - (frame % 40) * 0.5} fontSize={40}>z</text>
        </g>
      );
    default:
      return null;
  }
};

export const Face: React.FC<{expr: ExprName; frame: number; look?: number}> = ({expr, frame, look = 0}) => {
  const sp = EXPR[expr];
  const blink = frame % 96 > 92;
  const [aL, aR, dy] = sp.brow;
  const by = 150 + dy;
  const brow = (cx: number, a: number) => (
    <line x1={cx - 30} y1={by} x2={cx + 30} y2={by} stroke={C.ink} strokeWidth={10} strokeLinecap="round" transform={`rotate(${a} ${cx} ${by})`} />
  );
  return (
    <g>
      {brow(LX, aL)}
      {brow(RX, aR)}
      <Eye x={LX} type={sp.eye} blink={blink} look={look} />
      <Eye x={RX} type={sp.eye} blink={blink} look={look} />
      <Mouth type={sp.mouth} />
      <Extras extra={sp.extra} frame={frame} />
    </g>
  );
};
