import React from 'react';
import {interpolate, useCurrentFrame} from 'remotion';
import {C} from '../data/config';
import {CAPTIONS} from '../data/captions';
import {SUBTITLE} from '../data/layout';

/** Subtitle global (di luar kamera). Maks 2 baris, kata penting kuning. */
export const Subtitle: React.FC = () => {
  const frame = useCurrentFrame();
  const cap = CAPTIONS.find((c) => frame >= c.start && frame < c.end);
  if (!cap) return null;
  const k = interpolate(frame - cap.start, [0, 4], [0.9, 1], {extrapolateRight: 'clamp'});
  return (
    <div style={{position: 'absolute', left: SUBTITLE.x, top: SUBTITLE.y, width: SUBTITLE.w, height: SUBTITLE.h, display: 'flex', alignItems: 'center', justifyContent: 'center'}}>
      <div
        style={{
          transform: `scale(${k})`,
          background: 'rgba(0,0,0,0.5)',
          borderRadius: 30,
          padding: '14px 30px',
          textAlign: 'center',
          fontFamily: "'Arial Black', Impact, 'Helvetica Neue', Arial, sans-serif",
          fontWeight: 900,
          fontSize: 60,
          lineHeight: 1.15,
          color: C.white,
          WebkitTextStroke: '8px #000',
          paintOrder: 'stroke fill',
        }}
      >
        {cap.lines.map((ln, i) => (
          <div key={i} style={{whiteSpace: 'nowrap'}}>
            {ln.map((w, j) => (
              <span key={j} style={{color: w.hi ? C.yellow : C.white}}>
                {w.text}
                {j < ln.length - 1 ? ' ' : ''}
              </span>
            ))}
          </div>
        ))}
      </div>
    </div>
  );
};
