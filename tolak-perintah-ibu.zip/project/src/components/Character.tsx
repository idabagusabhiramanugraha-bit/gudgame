import React from 'react';
import {Easing, interpolate} from 'remotion';
import {C} from '../data/config';
import {ExprName, Face} from './CharacterExpressions';

/** Sendi: [bahu/pinggul, siku/lutut] dalam derajat. Positif = keluar (menjauh dari badan). */
export type Joint = [number, number];
export type Pose = {aL: Joint; aR: Joint; lL: Joint; lR: Joint; tilt: number; lean: number; bob: number};

const IDLE: Pose = {aL: [10, 12], aR: [10, 12], lL: [4, 0], lR: [4, 0], tilt: 0, lean: 0, bob: 0};
export const mkPose = (p: Partial<Pose>): Pose => ({...IDLE, ...p});

export const POSES = {
  idle: IDLE,
  hips: mkPose({aL: [42, -112], aR: [42, -112]}),
  fold: mkPose({aL: [22, -128], aR: [22, -128]}),
  stop: mkPose({aL: [85, 85], aR: [85, 85]}),
  stopOne: mkPose({aL: [14, 10], aR: [85, 85]}),
  cheer: mkPose({aL: [160, 20], aR: [160, 20], lL: [12, 0], lR: [12, 0]}),
  lounge: mkPose({aL: [110, 120], aR: [110, 120], lL: [34, 30], lR: [70, -60]}),
  panic: mkPose({aL: [130, 40], aR: [110, -30], lL: [14, 0], lR: [14, 0], lean: -4}),
  plead: mkPose({aL: [35, -150], aR: [35, -150], lean: 6}),
  shock: mkPose({aL: [55, 50], aR: [55, 50], lL: [18, 0], lR: [18, 0]}),
  point: mkPose({aL: [42, -112], aR: [88, 4]}),
  shout: mkPose({aL: [60, -30], aR: [60, -30], lean: 6}),
  belly: mkPose({aL: [24, -120], aR: [24, -120], lean: 8}),
  hold: mkPose({aL: [40, -112], aR: [62, -52]}),
  slump: mkPose({aL: [6, 8], aR: [6, 8], lean: 12, tilt: 8}),
  wave: mkPose({aL: [110, 40], aR: [110, -40]}),
};

const mixJ = (a: Joint, b: Joint, t: number): Joint => [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t];
export const mix = (a: Pose, b: Pose, t: number): Pose => ({
  aL: mixJ(a.aL, b.aL, t),
  aR: mixJ(a.aR, b.aR, t),
  lL: mixJ(a.lL, b.lL, t),
  lR: mixJ(a.lR, b.lR, t),
  tilt: a.tilt + (b.tilt - a.tilt) * t,
  lean: a.lean + (b.lean - a.lean) * t,
  bob: a.bob + (b.bob - a.bob) * t,
});

export type PoseKey = {f: number; pose: Pose};

/** Interpolasi antar keyframe pose dengan overshoot (anticipation/follow-through). */
export const poseAt = (frame: number, keys: PoseKey[]): Pose => {
  if (frame <= keys[0].f) return keys[0].pose;
  for (let i = 0; i < keys.length - 1; i++) {
    const a = keys[i];
    const b = keys[i + 1];
    if (frame <= b.f) {
      const t = interpolate(frame, [a.f, b.f], [0, 1], {
        easing: Easing.out(Easing.back(1.5)),
        extrapolateLeft: 'clamp',
        extrapolateRight: 'clamp',
      });
      return mix(a.pose, b.pose, t);
    }
  }
  return keys[keys.length - 1].pose;
};

export const walkPose = (frame: number, base: Pose = IDLE, speed = 0.45, amp = 26): Pose => {
  const s = Math.sin(frame * speed);
  return {
    ...base,
    lL: [amp * s, Math.max(0, -amp * s) * 1.2],
    lR: [-amp * s, Math.max(0, amp * s) * 1.2],
    aL: [base.aL[0] - amp * s * 0.8, base.aL[1]],
    aR: [base.aR[0] + amp * s * 0.8, base.aR[1]],
    bob: -Math.abs(s) * 9,
  };
};

type Who = 'kid' | 'mom';

const Leg: React.FC<{side: 'L' | 'R'; j: Joint; hx: number; hy: number; l1: number; l2: number}> = ({side, j, hx, hy, l1, l2}) => {
  const sg = side === 'L' ? 1 : -1;
  return (
    <g transform={`translate(${hx} ${hy}) rotate(${sg * j[0]})`}>
      <line x1={0} y1={0} x2={0} y2={l1} stroke={C.ink} strokeWidth={14} strokeLinecap="round" />
      <g transform={`translate(0 ${l1}) rotate(${sg * j[1]})`}>
        <line x1={0} y1={0} x2={0} y2={l2} stroke={C.ink} strokeWidth={14} strokeLinecap="round" />
        <ellipse cx={-sg * 14} cy={l2 + 4} rx={30} ry={15} fill={C.ink} />
      </g>
    </g>
  );
};

const Arm: React.FC<{who: Who; side: 'L' | 'R'; j: Joint; sx: number; sy: number; hold?: React.ReactNode; upright?: boolean}> = ({who, side, j, sx, sy, hold, upright}) => {
  const sg = side === 'L' ? 1 : -1;
  const kid = who === 'kid';
  const up = kid ? 105 : 98;
  const fo = kid ? 100 : 86;
  const sleeve = kid ? C.hoodie : C.blouse;
  const sleeveLen = kid ? 58 : up;
  return (
    <g transform={`translate(${sx} ${sy}) rotate(${sg * j[0]})`}>
      <line x1={0} y1={0} x2={0} y2={sleeveLen} stroke={C.ink} strokeWidth={40} strokeLinecap="round" />
      <line x1={0} y1={0} x2={0} y2={sleeveLen} stroke={sleeve} strokeWidth={28} strokeLinecap="round" />
      {kid && <line x1={0} y1={sleeveLen} x2={0} y2={up} stroke={C.ink} strokeWidth={13} strokeLinecap="round" />}
      <g transform={`translate(0 ${up}) rotate(${sg * j[1]})`}>
        {kid ? (
          <line x1={0} y1={0} x2={0} y2={fo} stroke={C.ink} strokeWidth={13} strokeLinecap="round" />
        ) : (
          <g>
            <line x1={0} y1={0} x2={0} y2={fo} stroke={C.ink} strokeWidth={40} strokeLinecap="round" />
            <line x1={0} y1={0} x2={0} y2={fo} stroke={C.blouse} strokeWidth={28} strokeLinecap="round" />
            <line x1={0} y1={fo - 4} x2={0} y2={fo + 22} stroke={C.ink} strokeWidth={15} strokeLinecap="round" />
          </g>
        )}
        <g transform={`translate(0 ${kid ? fo : fo + 22})`}>
          <circle r={16} fill={C.ink} />
          {hold && <g transform={upright ? `rotate(${-sg * (j[0] + j[1])})` : undefined}>{hold}</g>}
        </g>
      </g>
    </g>
  );
};

const KidTorso: React.FC = () => (
  <g stroke={C.ink} strokeWidth={7} strokeLinejoin="round">
    <path d="M 118 322 Q 200 306 282 322 L 294 506 Q 200 544 106 506 Z" fill={C.hoodie} />
    <ellipse cx={200} cy={322} rx={56} ry={16} fill={C.hoodieDark} />
    <path d="M 134 442 Q 200 474 266 442 L 274 508 Q 200 526 126 508 Z" fill={C.hoodieDark} strokeWidth={5} />
    <path d="M 108 506 Q 200 546 292 506" fill="none" strokeWidth={9} />
    <path d="M 180 334 L 177 404" stroke={C.white} strokeWidth={8} strokeLinecap="round" />
    <path d="M 222 334 L 225 404" stroke={C.white} strokeWidth={8} strokeLinecap="round" />
  </g>
);

const MomTorso: React.FC = () => (
  <g stroke={C.ink} strokeWidth={7} strokeLinejoin="round">
    <path d="M 120 322 Q 200 308 280 322 L 288 470 L 112 470 Z" fill={C.blouse} />
    <path d="M 144 330 Q 200 318 256 330 L 268 470 L 296 612 Q 200 646 104 612 L 132 470 Z" fill={C.apron} />
    <path d="M 132 470 L 268 470" fill="none" stroke={C.apronDark} strokeWidth={5} />
    <rect x={160} y={510} width={80} height={62} rx={8} fill={C.apronDark} strokeWidth={5} />
    <path d="M 150 332 L 128 322 M 250 332 L 272 322" fill="none" strokeWidth={5} stroke={C.apronDark} />
  </g>
);

const KidHair: React.FC = () => (
  <g>
    <path
      d="M 64 152 L 50 88 L 98 108 L 90 30 L 140 82 L 160 4 L 196 74 L 238 -4 L 252 78 L 298 20 L 290 96 L 340 70 L 324 152 Q 300 114 262 110 Q 200 94 140 110 Q 100 114 64 152 Z"
      fill={C.hair}
      stroke={C.ink}
      strokeWidth={7}
      strokeLinejoin="round"
    />
    <path d="M 110 96 L 128 70 M 176 70 L 190 40 M 250 80 L 266 52 M 214 96 L 232 70" stroke={C.hairHi} strokeWidth={6} strokeLinecap="round" fill="none" />
  </g>
);

const MomHair: React.FC = () => (
  <g>
    <circle cx={200} cy={22} r={54} fill={C.hair} stroke={C.ink} strokeWidth={7} />
    <path d="M 176 6 Q 200 -8 226 10 M 170 30 Q 200 44 232 28" stroke={C.hairHi} strokeWidth={5} fill="none" strokeLinecap="round" />
  </g>
);

const MomHairFront: React.FC = () => (
  <g>
    <path
      d="M 60 180 C 52 66 130 40 200 40 C 272 40 348 66 340 180 C 324 124 292 104 252 102 C 222 124 152 116 120 102 C 98 122 70 150 60 180 Z"
      fill={C.hair}
      stroke={C.ink}
      strokeWidth={7}
      strokeLinejoin="round"
    />
    <path d="M 332 150 Q 352 190 330 222" fill="none" stroke={C.hair} strokeWidth={14} strokeLinecap="round" />
    <path d="M 100 70 Q 130 52 160 50" stroke={C.hairHi} strokeWidth={6} fill="none" strokeLinecap="round" />
  </g>
);

export type CharProps = {
  who: Who;
  cx: number;
  cy: number;
  s: number;
  pose: Pose;
  expr: ExprName;
  frame: number;
  flip?: boolean;
  rot?: number;
  sx?: number;
  sy?: number;
  look?: number;
  opacity?: number;
  holdL?: React.ReactNode;
  holdR?: React.ReactNode;
  /** Properti di tangan tetap tegak (tidak ikut berputar dengan lengan). */
  upright?: boolean;
  shadow?: boolean;
};

/** Rig 2D berlayer: kaki, badan, lengan (bahu+siku), kepala, rambut, wajah. */
export const Character: React.FC<CharProps> = (p) => {
  const mom = p.who === 'mom';
  const hipY = mom ? 600 : 535;
  const legLen = mom ? 68 : 100;
  const breathe = Math.sin(p.frame * 0.18) * 1.5;
  const wob = Math.sin(p.frame * 0.25) * 1.6;
  const sgn = p.flip ? -1 : 1;
  const tf = `translate(${p.cx} ${p.cy}) rotate(${p.rot ?? 0}) scale(${sgn * p.s * (p.sx ?? 1)} ${p.s * (p.sy ?? 1)}) translate(-200 -380)`;
  const pose = p.pose;
  return (
    <g transform={tf} opacity={p.opacity ?? 1}>
      {p.shadow !== false && <ellipse cx={200} cy={748} rx={115} ry={14} fill="rgba(0,0,0,0.18)" />}
      <g transform={`translate(0 ${pose.bob})`}>
        <Leg side="L" j={pose.lL} hx={168} hy={hipY} l1={legLen} l2={legLen} />
        <Leg side="R" j={pose.lR} hx={232} hy={hipY} l1={legLen} l2={legLen} />
        <g transform={`rotate(${pose.lean} 200 ${hipY})`}>
          {mom ? <MomTorso /> : <KidTorso />}
          <Arm who={p.who} side="L" j={pose.aL} sx={124} sy={346} hold={p.holdL} upright={p.upright} />
          <Arm who={p.who} side="R" j={pose.aR} sx={276} sy={346} hold={p.holdR} upright={p.upright} />
          <g transform={`rotate(${pose.tilt} 200 330) translate(0 ${breathe})`}>
            {mom && <MomHair />}
            <circle cx={200} cy={190} r={140} fill={C.white} stroke={C.ink} strokeWidth={8} />
            <path d="M 300 120 A 140 140 0 0 1 300 260 A 160 160 0 0 0 300 120 Z" fill="rgba(120,130,160,0.14)" />
            <Face expr={p.expr} frame={p.frame} look={p.look} />
            <g transform={`rotate(${wob} 200 120)`}>{mom ? <MomHairFront /> : <KidHair />}</g>
          </g>
        </g>
      </g>
    </g>
  );
};

/** Posisi dunia telapak tangan (forward kinematics) agar efek/properti menempel di tangan. */
export const handPos = (
  p: {who: Who; cx: number; cy: number; s: number; pose: Pose; flip?: boolean; rot?: number},
  side: 'L' | 'R'
): [number, number] => {
  const sg = side === 'L' ? 1 : -1;
  const j = side === 'L' ? p.pose.aL : p.pose.aR;
  const kid = p.who === 'kid';
  const up = kid ? 105 : 98;
  const fo = kid ? 100 : 86;
  const ext = kid ? fo : fo + 22;
  const sx = side === 'L' ? 124 : 276;
  const sy = 346;
  const a1 = (sg * j[0] * Math.PI) / 180;
  const a2 = a1 + (sg * j[1] * Math.PI) / 180;
  let x = sx - Math.sin(a1) * up - Math.sin(a2) * ext;
  let y = sy + Math.cos(a1) * up + Math.cos(a2) * ext;
  const hipY = kid ? 535 : 600;
  const l = (p.pose.lean * Math.PI) / 180;
  const dx = x - 200;
  const dy = y - hipY;
  x = 200 + dx * Math.cos(l) - dy * Math.sin(l);
  y = hipY + dx * Math.sin(l) + dy * Math.cos(l) + p.pose.bob;
  const r = ((p.rot ?? 0) * Math.PI) / 180;
  const sgn = p.flip ? -1 : 1;
  const wx = (x - 200) * p.s * sgn;
  const wy = (y - 380) * p.s;
  return [p.cx + wx * Math.cos(r) - wy * Math.sin(r), p.cy + wx * Math.sin(r) + wy * Math.cos(r)];
};
