import React from 'react';

const X0 = -300;
const W = 1680;

export const MorningLighting: React.FC = () => (
  <g style={{pointerEvents: 'none'}}>
    <defs>
      <linearGradient id="mornWash" x1="1" y1="0" x2="0" y2="1">
        <stop offset="0" stopColor="#FFD98A" stopOpacity={0.5} />
        <stop offset="1" stopColor="#FFB86B" stopOpacity={0.12} />
      </linearGradient>
    </defs>
    <rect x={X0} y={0} width={W} height={1920} fill="url(#mornWash)" />
    <polygon points="560,650 890,650 760,1920 120,1920" fill="#FFF3C4" opacity={0.2} />
  </g>
);

export const NoonLighting: React.FC = () => (
  <g style={{pointerEvents: 'none'}}>
    <rect x={X0} y={0} width={W} height={1920} fill="#FFFFFF" opacity={0.1} />
  </g>
);

export const AfternoonLighting: React.FC = () => (
  <g style={{pointerEvents: 'none'}}>
    <defs>
      <radialGradient id="aftVig" cx="0.5" cy="0.5" r="0.75">
        <stop offset="0.5" stopColor="#7A2E10" stopOpacity={0} />
        <stop offset="1" stopColor="#7A2E10" stopOpacity={0.45} />
      </radialGradient>
    </defs>
    <rect x={X0} y={0} width={W} height={1920} fill="#F2A65A" opacity={0.32} />
    <rect x={X0} y={0} width={W} height={1920} fill="url(#aftVig)" />
  </g>
);

export const NightLighting: React.FC<{glowX?: number; glowY?: number}> = ({glowX = 540, glowY = 300}) => (
  <g style={{pointerEvents: 'none'}}>
    <defs>
      <radialGradient id="nightGlow" cx="0.5" cy="0.5" r="0.5">
        <stop offset="0" stopColor="#FFE2A0" stopOpacity={0.55} />
        <stop offset="1" stopColor="#FFE2A0" stopOpacity={0} />
      </radialGradient>
    </defs>
    <rect x={X0} y={0} width={W} height={1920} fill="#2A2470" opacity={0.5} />
    <circle cx={glowX} cy={glowY} r={760} fill="url(#nightGlow)" />
  </g>
);

export const DullLighting: React.FC = () => (
  <g style={{pointerEvents: 'none'}}>
    <rect x={X0} y={0} width={W} height={1920} fill="#6C5BA8" opacity={0.3} />
  </g>
);
