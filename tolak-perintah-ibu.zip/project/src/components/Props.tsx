import React from 'react';
import {C} from '../data/config';

type P = {x: number; y: number; s?: number};
const T = (p: P) => `translate(${p.x} ${p.y}) scale(${p.s ?? 1})`;
const st = {stroke: C.ink, strokeWidth: 6, strokeLinejoin: 'round' as const};

/** Sapu: dipegang di tangan (origin = telapak). */
export const Broom: React.FC = () => (
  <g>
    <line x1={0} y1={-170} x2={0} y2={190} stroke="#B98A4E" strokeWidth={14} strokeLinecap="round" />
    <line x1={0} y1={-170} x2={0} y2={190} stroke={C.ink} strokeWidth={2} />
    <path d="M -34 190 L 34 190 L 62 300 Q 0 322 -62 300 Z" fill="#D9A441" {...st} />
    <path d="M -20 210 L -30 296 M 0 210 L 0 304 M 20 210 L 30 296" stroke={C.ink} strokeWidth={3} fill="none" />
  </g>
);

export const Spatula: React.FC<{rotate?: number}> = ({rotate = 0}) => (
  <g transform={`rotate(${rotate})`}>
    <line x1={0} y1={-10} x2={0} y2={110} stroke="#8A5A36" strokeWidth={12} strokeLinecap="round" />
    <rect x={-22} y={104} width={44} height={60} rx={8} fill="#C0C4CC" {...st} />
  </g>
);

/** Wajan di tangan: gagang searah lengan, badan wajan di ujung. */
export const Pan: React.FC<{tilt?: number}> = ({tilt = 0}) => (
  <g transform={`rotate(${tilt})`}>
    <line x1={0} y1={-4} x2={0} y2={90} stroke="#2B2B2B" strokeWidth={14} strokeLinecap="round" />
    <ellipse cx={0} cy={150} rx={96} ry={28} fill="#3A3A40" {...st} />
    <ellipse cx={0} cy={142} rx={80} ry={18} fill="#1d1d22" />
  </g>
);

export const DigitalClock: React.FC<P & {text: string; frame: number}> = (p) => (
  <g transform={T(p)}>
    <rect x={0} y={0} width={300} height={170} rx={20} fill="#2a2230" {...st} />
    <rect x={14} y={14} width={272} height={142} rx={12} fill="#120d16" />
    <text x={150} y={118} textAnchor="middle" fontSize={96} fontWeight={900} fontFamily="'Courier New', monospace" fill={C.red} opacity={p.frame % 20 < 14 ? 1 : 0.55}>
      {p.text}
    </text>
    <rect x={30} y={170} width={30} height={16} fill={C.ink} />
    <rect x={240} y={170} width={30} height={16} fill={C.ink} />
  </g>
);

export const WallClock: React.FC<P & {hour: number; min?: number}> = (p) => {
  const hA = ((p.hour % 12) / 12) * 360 + ((p.min ?? 0) / 60) * 30;
  const mA = ((p.min ?? 0) / 60) * 360;
  return (
    <g transform={T(p)}>
      <circle r={74} fill="#FFF8E8" {...st} strokeWidth={8} />
      {Array.from({length: 12}).map((_, i) => (
        <line key={i} x1={0} y1={-62} x2={0} y2={-52} stroke={C.ink} strokeWidth={4} transform={`rotate(${i * 30})`} />
      ))}
      <line x1={0} y1={0} x2={0} y2={-38} stroke={C.ink} strokeWidth={8} strokeLinecap="round" transform={`rotate(${hA})`} />
      <line x1={0} y1={0} x2={0} y2={-56} stroke={C.ink} strokeWidth={5} strokeLinecap="round" transform={`rotate(${mA})`} />
      <circle r={6} fill={C.ink} />
    </g>
  );
};

export const Plate: React.FC<P> = (p) => (
  <g transform={T(p)}>
    <ellipse cx={0} cy={0} rx={70} ry={16} fill="#FFFFFF" {...st} strokeWidth={5} />
    <ellipse cx={0} cy={-2} rx={44} ry={8} fill="#E8EEF5" />
  </g>
);

export const PlateStack: React.FC<P & {n: number; sway?: number}> = (p) => (
  <g transform={T(p)}>
    {Array.from({length: p.n}).map((_, i) => (
      <g key={i} transform={`translate(${Math.sin(i * 2.3) * 8 + (p.sway ?? 0) * i} ${-i * 15})`}>
        <Plate x={0} y={0} />
        {i % 3 === 1 && <ellipse cx={14} cy={-4} rx={22} ry={5} fill="#E7A24A" />}
      </g>
    ))}
  </g>
);

export const Glass: React.FC<P & {tilt?: number}> = (p) => (
  <g transform={`${T(p)} rotate(${p.tilt ?? 0})`}>
    <path d="M -22 -70 L 22 -70 L 16 0 L -16 0 Z" fill="rgba(180,220,255,0.7)" {...st} strokeWidth={5} />
    <path d="M -18 -30 L 18 -30 L 16 0 L -16 0 Z" fill="rgba(120,190,255,0.8)" />
  </g>
);

const CLOTHES = ['#E5383B', '#4F8EF7', '#F2C14E', '#7BC47F', '#C78CE0', '#F29E4C'];
export const ClothesPile: React.FC<P & {n?: number}> = (p) => (
  <g transform={T(p)}>
    {Array.from({length: p.n ?? 7}).map((_, i) => (
      <path key={i} transform={`translate(${(i - 3) * 34} ${-Math.abs(Math.sin(i * 1.7)) * 40}) rotate(${(i * 47) % 70 - 35})`}
        d="M -44 0 Q -50 -34 -20 -38 L 20 -38 Q 50 -34 44 0 Q 0 14 -44 0 Z" fill={CLOTHES[i % CLOTHES.length]} {...st} strokeWidth={5} />
    ))}
  </g>
);

export const Basket: React.FC<P & {overflow?: boolean}> = (p) => (
  <g transform={T(p)}>
    {p.overflow && <ClothesPile x={0} y={-150} s={1.5} n={8} />}
    <path d="M -110 -130 L 110 -130 L 92 0 L -92 0 Z" fill="#E7B04A" {...st} />
    {Array.from({length: 4}).map((_, r) => (
      <g key={r}>
        {Array.from({length: 6}).map((_, c) => (
          <rect key={c} x={-82 + c * 28 + (r % 2) * 6} y={-112 + r * 26} width={16} height={14} rx={3} fill="#9B6B1F" />
        ))}
      </g>
    ))}
    <rect x={-116} y={-142} width={232} height={18} rx={9} fill="#D69A2E" {...st} />
  </g>
);

export const Pot: React.FC<P> = (p) => (
  <g transform={T(p)}>
    <rect x={-60} y={-80} width={120} height={80} rx={10} fill="#9AA3AF" {...st} />
    <rect x={-70} y={-92} width={140} height={16} rx={8} fill="#C0C4CC" {...st} />
    <line x1={60} y1={-50} x2={96} y2={-56} stroke={C.ink} strokeWidth={10} strokeLinecap="round" />
  </g>
);

export const Bowl: React.FC<P> = (p) => (
  <g transform={T(p)}>
    <path d="M -64 -40 Q 0 20 64 -40 Z" fill="#F2F2F2" {...st} />
    <ellipse cx={0} cy={-42} rx={64} ry={12} fill="#7BC47F" {...st} strokeWidth={5} />
    <circle cx={-18} cy={-50} r={9} fill={C.red} /> <circle cx={20} cy={-48} r={8} fill={C.yellow} />
  </g>
);

export const Bill: React.FC<P> = (p) => (
  <g transform={T(p)}>
    <rect x={-50} y={-26} width={100} height={52} rx={6} fill="#8ED08B" {...st} strokeWidth={5} />
    <circle r={14} fill="#CFF0CC" stroke={C.ink} strokeWidth={4} />
  </g>
);

export const Plant: React.FC<P> = (p) => (
  <g transform={T(p)}>
    <path d="M -50 -90 L 50 -90 L 38 0 L -38 0 Z" fill="#C46B4A" {...st} />
    {[-50, -20, 10, 40].map((a, i) => (
      <path key={i} transform={`rotate(${a} 0 -90)`} d="M 0 -90 Q 30 -170 0 -250 Q -30 -170 0 -90 Z" fill={i % 2 ? '#4FA85D' : '#3E8E4D'} {...st} strokeWidth={5} />
    ))}
  </g>
);

export const Frame: React.FC<P & {w?: number; h?: number; kind?: number}> = (p) => (
  <g transform={T(p)}>
    <rect width={p.w ?? 150} height={p.h ?? 190} fill="#8A5A36" {...st} />
    <rect x={12} y={12} width={(p.w ?? 150) - 24} height={(p.h ?? 190) - 24} fill={p.kind === 1 ? '#9ED0F0' : '#F4D79A'} stroke={C.ink} strokeWidth={3} />
    {p.kind === 1 ? <path d="M 12 150 L 60 90 L 90 124 L 120 80 L 138 150 Z" fill="#6FAF72" /> : <circle cx={75} cy={90} r={30} fill="#E58A4B" />}
  </g>
);

/** Sofa. layer 'back' digambar sebelum karakter, 'front' sesudahnya. Origin = tengah-bawah. */
export const Sofa: React.FC<P & {layer: 'back' | 'front'}> = (p) => (
  <g transform={T(p)}>
    {p.layer === 'back' ? (
      <g>
        <rect x={-340} y={-330} width={680} height={230} rx={50} fill="#8A3F4A" {...st} />
        <rect x={-400} y={-230} width={90} height={230} rx={34} fill="#733340" {...st} />
        <rect x={310} y={-230} width={90} height={230} rx={34} fill="#733340" {...st} />
        <rect x={-320} y={-140} width={640} height={60} fill="#9C4A57" stroke="none" />
      </g>
    ) : (
      <g>
        <rect x={-320} y={-120} width={640} height={96} rx={30} fill="#A44E5C" {...st} />
        <line x1={0} y1={-118} x2={0} y2={-26} stroke={C.ink} strokeWidth={4} />
        <rect x={-380} y={-24} width={22} height={28} fill={C.ink} />
        <rect x={358} y={-24} width={22} height={28} fill={C.ink} />
      </g>
    )}
  </g>
);

/** Tempat tidur (tampak depan-samping). Kepala di kanan. Origin = kiri-bawah. */
export const Bed: React.FC<P & {layer: 'back' | 'front'; messy?: boolean}> = (p) => (
  <g transform={T(p)}>
    {p.layer === 'back' ? (
      <g>
        <rect x={600} y={-320} width={60} height={320} rx={16} fill="#8A5A36" {...st} />
        <rect x={0} y={-150} width={620} height={110} rx={20} fill="#F4F0FF" {...st} />
        <ellipse cx={520} cy={-176} rx={86} ry={38} fill="#FFFFFF" {...st} />
        {p.messy && <path d="M 330 -150 Q 400 -230 470 -150 Z" fill="#8E7CC3" {...st} />}
      </g>
    ) : (
      <g>
        <rect x={0} y={-110} width={620} height={90} rx={14} fill="#8E7CC3" {...st} />
        <rect x={-14} y={-130} width={40} height={130} rx={12} fill="#8A5A36" {...st} />
        <rect x={10} y={-20} width={20} height={20} fill={C.ink} />
        <rect x={590} y={-20} width={20} height={20} fill={C.ink} />
        {p.messy && <path d="M 90 -110 Q 150 -190 230 -120 Q 270 -80 240 -50 L 100 -50 Z" fill="#6F5FB0" {...st} />}
      </g>
    )}
  </g>
);

/** Awan pikiran: konten anak di dalam (koordinat lokal 0..w, 0..h). */
export const ThoughtBubble: React.FC<{x: number; y: number; w: number; h: number; s?: number; tail?: [number, number]; children?: React.ReactNode}> = ({x, y, w, h, s = 1, tail, children}) => (
  <g transform={`translate(${x} ${y}) scale(${s})`}>
    {tail && (
      <g fill="#FFFFFF" {...st} strokeWidth={5}>
        <circle cx={w / 2 + (tail[0] - w / 2) * 0.55} cy={h + (tail[1] - h) * 0.4} r={18} />
        <circle cx={w / 2 + (tail[0] - w / 2) * 0.85} cy={h + (tail[1] - h) * 0.75} r={10} />
      </g>
    )}
    <g fill="#FFFFFF" {...st} strokeWidth={6}>
      <ellipse cx={w / 2} cy={h / 2} rx={w / 2} ry={h / 2} />
      <circle cx={w * 0.14} cy={h * 0.22} r={h * 0.2} />
      <circle cx={w * 0.86} cy={h * 0.24} r={h * 0.2} />
      <circle cx={w * 0.3} cy={h * 0.88} r={h * 0.18} />
      <circle cx={w * 0.72} cy={h * 0.88} r={h * 0.18} />
    </g>
    <ellipse cx={w / 2} cy={h / 2} rx={w / 2 - 4} ry={h / 2 - 4} fill="#FFFFFF" />
    {children}
  </g>
);

export const SpeechBubble: React.FC<{x: number; y: number; w: number; h: number; tailX: number; tailY: number; children?: React.ReactNode}> = ({x, y, w, h, tailX, tailY, children}) => (
  <g transform={`translate(${x} ${y})`}>
    <path d={`M ${w * 0.35} ${h - 4} L ${tailX} ${tailY} L ${w * 0.55} ${h - 4} Z`} fill="#FFFFFF" {...st} />
    <rect width={w} height={h} rx={h / 2} fill="#FFFFFF" {...st} />
    <rect x={w * 0.3} y={h - 12} width={w * 0.3} height={14} fill="#FFFFFF" />
    {children}
  </g>
);

export const Shower: React.FC<P & {frame: number}> = (p) => (
  <g transform={T(p)}>
    <line x1={0} y1={0} x2={0} y2={-130} stroke="#9AA3AF" strokeWidth={10} />
    <path d="M -40 -130 L 70 -130 L 56 -104 L -26 -104 Z" fill="#C0C4CC" {...st} strokeWidth={5} />
    {Array.from({length: 7}).map((_, i) => (
      <line key={i} x1={-20 + i * 14} y1={-96 + ((p.frame * 6 + i * 20) % 90)} x2={-24 + i * 14} y2={-76 + ((p.frame * 6 + i * 20) % 90)} stroke="#6EC6FF" strokeWidth={5} strokeLinecap="round" />
    ))}
  </g>
);
