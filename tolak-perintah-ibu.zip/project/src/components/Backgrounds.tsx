import React from 'react';
import {C} from '../data/config';
import {Frame, Plant} from './Props';

const st = {stroke: C.ink, strokeWidth: 6, strokeLinejoin: 'round' as const};
const X0 = -300;
const W = 1680;
const HORIZON = 1150;

const Floor: React.FC<{c1: string; c2: string}> = ({c1, c2}) => (
  <g>
    <rect x={X0} y={HORIZON} width={W} height={1920 - HORIZON} fill={c1} />
    {[1210, 1290, 1400, 1550, 1740].map((y) => (
      <line key={y} x1={X0} y1={y} x2={X0 + W} y2={y} stroke={c2} strokeWidth={4} />
    ))}
    {Array.from({length: 25}).map((_, i) => {
      const k = i - 12;
      return <line key={i} x1={540 + k * 70} y1={HORIZON} x2={540 + k * 190} y2={1920} stroke={c2} strokeWidth={3} />;
    })}
    <rect x={X0} y={HORIZON - 28} width={W} height={28} fill="#F5EEE2" {...st} strokeWidth={5} />
  </g>
);

const Window: React.FC<{x: number; y: number; w: number; h: number; night?: boolean; curtain?: string}> = ({x, y, w, h, night, curtain = '#E58A9B'}) => (
  <g>
    <defs>
      <linearGradient id={`sky${x}${y}`} x1="0" y1="0" x2="0" y2="1">
        <stop offset="0" stopColor={night ? '#1F1A4D' : '#8EC9FF'} />
        <stop offset="1" stopColor={night ? '#4A3F8A' : '#FFE9B0'} />
      </linearGradient>
    </defs>
    <rect x={x} y={y} width={w} height={h} fill={`url(#sky${x}${y})`} {...st} strokeWidth={10} />
    {night ? (
      <g fill={C.yellow}>
        <circle cx={x + w * 0.7} cy={y + h * 0.3} r={w * 0.1} />
        <circle cx={x + w * 0.25} cy={y + h * 0.2} r={4} />
        <circle cx={x + w * 0.4} cy={y + h * 0.5} r={3} />
      </g>
    ) : (
      <circle cx={x + w * 0.7} cy={y + h * 0.3} r={w * 0.12} fill="#FFD84A" stroke={C.ink} strokeWidth={4} />
    )}
    <line x1={x + w / 2} y1={y} x2={x + w / 2} y2={y + h} stroke={C.ink} strokeWidth={8} />
    <line x1={x} y1={y + h / 2} x2={x + w} y2={y + h / 2} stroke={C.ink} strokeWidth={8} />
    <rect x={x - 14} y={y + h} width={w + 28} height={20} fill="#F5EEE2" {...st} strokeWidth={5} />
    <rect x={x - 70} y={y - 30} width={w + 140} height={14} rx={7} fill="#6b4a2a" {...st} strokeWidth={4} />
    <path d={`M ${x - 56} ${y - 16} Q ${x + 10} ${y + h * 0.5} ${x - 40} ${y + h + 10} L ${x + 36} ${y + h + 10} Q ${x + 60} ${y + h * 0.5} ${x + 40} ${y - 16} Z`} fill={curtain} {...st} strokeWidth={5} />
    <path d={`M ${x + w + 56} ${y - 16} Q ${x + w - 10} ${y + h * 0.5} ${x + w + 40} ${y + h + 10} L ${x + w - 36} ${y + h + 10} Q ${x + w - 60} ${y + h * 0.5} ${x + w - 40} ${y - 16} Z`} fill={curtain} {...st} strokeWidth={5} />
  </g>
);

export const BedroomBackground: React.FC = () => (
  <g>
    <rect x={X0} y={0} width={W} height={HORIZON} fill="#CDBFE6" />
    <rect x={X0} y={880} width={W} height={HORIZON - 880} fill="#B9A8D8" />
    <line x1={X0} y1={880} x2={X0 + W} y2={880} stroke={C.ink} strokeWidth={5} />
    {Array.from({length: 14}).map((_, i) => (
      <circle key={i} cx={X0 + 60 + i * 125} cy={120 + ((i * 97) % 520)} r={6} fill="#E7DDF5" />
    ))}
    <Window x={560} y={230} w={330} h={420} />
    <Frame x={90} y={300} w={150} h={190} kind={1} />
    <Frame x={270} y={360} w={120} h={150} kind={0} />
    <g>
      <rect x={780} y={900} width={190} height={250} rx={10} fill={C.wood} {...st} />
      <rect x={796} y={930} width={158} height={80} rx={6} fill="#C28F5E" stroke={C.ink} strokeWidth={4} />
      <circle cx={875} cy={970} r={8} fill={C.ink} />
      <path d="M 840 900 L 910 900 L 896 820 L 854 820 Z" fill="#FFE9A0" {...st} strokeWidth={5} />
      <rect x={868} y={900} width={14} height={0} />
    </g>
    <Floor c1="#C79862" c2="#9B6E3E" />
    <ellipse cx={540} cy={1560} rx={500} ry={120} fill="#E5A3A3" stroke={C.ink} strokeWidth={5} />
    <ellipse cx={540} cy={1560} rx={380} ry={80} fill="none" stroke="#fff" strokeWidth={5} opacity={0.5} />
  </g>
);

export const LivingRoomBackground: React.FC<{night?: boolean}> = ({night}) => (
  <g>
    <rect x={X0} y={0} width={W} height={HORIZON} fill="#EFD9B8" />
    <rect x={X0} y={900} width={W} height={HORIZON - 900} fill="#D9BE94" />
    <line x1={X0} y1={900} x2={X0 + W} y2={900} stroke={C.ink} strokeWidth={5} />
    <Window x={360} y={320} w={320} h={300} night={night} curtain="#C46B4A" />
    {/* warung di seberang jendela */}
    <g>
      <rect x={380} y={520} width={140} height={100} fill="#F4D79A" stroke={C.ink} strokeWidth={4} />
      <rect x={374} y={496} width={152} height={34} fill={C.yellow} stroke={C.ink} strokeWidth={4} />
      <text x={450} y={522} textAnchor="middle" fontSize={22} fontWeight={900} fontFamily="Arial Black, Arial, sans-serif" fill={C.ink}>WARUNG</text>
    </g>
    <g>
      <rect x={790} y={330} width={230} height={820} rx={10} fill="#8A5A36" {...st} />
      <rect x={812} y={356} width={186} height={330} rx={6} fill="#A06C42" stroke={C.ink} strokeWidth={4} />
      <rect x={812} y={716} width={186} height={400} rx={6} fill="#A06C42" stroke={C.ink} strokeWidth={4} />
      <circle cx={982} cy={760} r={12} fill={C.yellow} stroke={C.ink} strokeWidth={4} />
    </g>
    <Frame x={90} y={330} w={170} h={210} kind={0} />
    <Plant x={40} y={1150} s={1.2} />
    <g>
      <rect x={1080} y={560} width={12} height={590} fill="#444" />
      <path d="M 1040 560 L 1130 560 L 1112 480 L 1058 480 Z" fill="#FFE9A0" {...st} strokeWidth={5} />
    </g>
    <Floor c1="#C79862" c2="#9B6E3E" />
    <ellipse cx={540} cy={1540} rx={520} ry={130} fill="#9FB7D9" stroke={C.ink} strokeWidth={5} />
    <ellipse cx={540} cy={1540} rx={400} ry={90} fill="none" stroke="#fff" strokeWidth={5} opacity={0.5} />
  </g>
);

export const KitchenBackground: React.FC<{night?: boolean}> = ({night}) => (
  <g>
    <rect x={X0} y={0} width={W} height={HORIZON} fill="#F6E9CF" />
    {Array.from({length: 24}).map((_, i) => (
      <line key={i} x1={X0 + i * 70} y1={430} x2={X0 + i * 70} y2={960} stroke="#E3D2AE" strokeWidth={3} />
    ))}
    {[500, 580, 660, 740, 820, 900].map((y) => (
      <line key={y} x1={X0} y1={y} x2={X0 + W} y2={y} stroke="#E3D2AE" strokeWidth={3} />
    ))}
    {/* lemari atas */}
    {Array.from({length: 8}).map((_, i) => (
      <g key={i}>
        <rect x={X0 + i * 210} y={150} width={210} height={250} fill={C.wood} {...st} strokeWidth={5} />
        <rect x={X0 + i * 210 + 18} y={168} width={174} height={214} fill="#C28F5E" stroke={C.ink} strokeWidth={3} />
        <circle cx={X0 + i * 210 + (i % 2 ? 40 : 170)} cy={340} r={8} fill={C.ink} />
      </g>
    ))}
    {/* kulkas */}
    <rect x={30} y={190} width={210} height={960} rx={18} fill="#E8EEF4" {...st} />
    <line x1={34} y1={540} x2={236} y2={540} stroke={C.ink} strokeWidth={5} />
    <rect x={200} y={330} width={14} height={120} rx={7} fill="#9AA3AF" stroke={C.ink} strokeWidth={3} />
    <rect x={200} y={620} width={14} height={160} rx={7} fill="#9AA3AF" stroke={C.ink} strokeWidth={3} />
    {/* meja dapur */}
    <rect x={240} y={980} width={W} height={170} fill={C.wood} {...st} />
    {Array.from({length: 7}).map((_, i) => (
      <rect key={i} x={260 + i * 170} y={1000} width={150} height={134} fill="#C28F5E" stroke={C.ink} strokeWidth={3} />
    ))}
    <rect x={240} y={950} width={W} height={34} fill="#E4D6BA" {...st} strokeWidth={5} />
    {/* wastafel */}
    <rect x={290} y={930} width={210} height={26} rx={10} fill="#C0C4CC" {...st} strokeWidth={5} />
    <path d="M 480 930 L 480 840 Q 480 810 450 810 L 420 810" fill="none" stroke="#9AA3AF" strokeWidth={14} strokeLinecap="round" />
    {/* kompor + hood */}
    <rect x={640} y={900} width={200} height={50} rx={8} fill="#3A3A40" {...st} strokeWidth={5} />
    <ellipse cx={700} cy={900} rx={34} ry={9} fill="#6A6A72" /> <ellipse cx={790} cy={900} rx={34} ry={9} fill="#6A6A72" />
    <path d="M 600 420 L 880 420 L 820 560 L 660 560 Z" fill="#B9C0CC" {...st} />
    <rect x={700} y={330} width={80} height={92} fill="#9AA3AF" {...st} strokeWidth={5} />
    <Window x={960} y={360} w={260} h={300} night={night} curtain="#E7B04A" />
    <Floor c1="#B78A58" c2="#8B6338" />
    <ellipse cx={540} cy={1560} rx={430} ry={100} fill="#D9A441" stroke={C.ink} strokeWidth={5} />
    {/* lampu gantung */}
    <line x1={520} y1={0} x2={520} y2={150} stroke={C.ink} strokeWidth={5} />
    <path d="M 450 150 L 590 150 L 556 224 L 484 224 Z" fill="#FFE9A0" {...st} strokeWidth={5} />
  </g>
);

/** Potongan rumah lebar (dapur | ruang keluarga | kamar) untuk adegan berantakan. */
export const HouseWideBackground: React.FC = () => (
  <g>
    <defs>
      <clipPath id="clipK"><rect x={-300} y={0} width={680} height={1920} /></clipPath>
      <clipPath id="clipL"><rect x={380} y={0} width={520} height={1920} /></clipPath>
      <clipPath id="clipB"><rect x={900} y={0} width={480} height={1920} /></clipPath>
    </defs>
    <g clipPath="url(#clipK)"><g transform="translate(-330 0)"><KitchenBackground /></g></g>
    <g clipPath="url(#clipL)"><g transform="translate(80 0)"><LivingRoomBackground /></g></g>
    <g clipPath="url(#clipB)"><g transform="translate(800 0)"><BedroomBackground /></g></g>
    <rect x={376} y={0} width={8} height={1920} fill={C.ink} />
    <rect x={896} y={0} width={8} height={1920} fill={C.ink} />
  </g>
);
