import React from 'react';
import {Easing, interpolate, useCurrentFrame} from 'remotion';

export type CamKey = {f: number; s: number; x: number; y: number; r?: number};
export type Shake = {from: number; to: number; amp: number};

const ease = Easing.inOut(Easing.cubic);

const val = (frame: number, keys: CamKey[], pick: (k: CamKey) => number) => {
  if (keys.length === 1) return pick(keys[0]);
  return interpolate(frame, keys.map((k) => k.f), keys.map(pick), {
    easing: ease,
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });
};

/** Kamera 2D: push-in/pull-out, pan, rotasi kecil, dan camera shake deterministik. */
export const CameraEffects: React.FC<{keys: CamKey[]; shake?: Shake[]; children?: React.ReactNode}> = ({keys, shake = [], children}) => {
  const frame = useCurrentFrame();
  let x = val(frame, keys, (k) => k.x);
  let y = val(frame, keys, (k) => k.y);
  const s = val(frame, keys, (k) => k.s);
  const r = val(frame, keys, (k) => k.r ?? 0);
  for (const sh of shake) {
    if (frame >= sh.from && frame <= sh.to) {
      const fall = 1 - (frame - sh.from) / Math.max(1, sh.to - sh.from) * 0.6;
      x += Math.sin(frame * 2.9) * sh.amp * fall;
      y += Math.cos(frame * 3.7) * sh.amp * fall;
    }
  }
  return (
    <div style={{position: 'absolute', left: 0, top: 0, width: 1080, height: 1920, overflow: 'hidden'}}>
      <div style={{position: 'absolute', left: 0, top: 0, width: 1080, height: 1920, transformOrigin: '540px 960px', transform: `translate(${x}px, ${y}px) scale(${s}) rotate(${r}deg)`}}>
        {children}
      </div>
    </div>
  );
};

/** Dunia SVG lebar (x -300..1380) agar kamera bisa pan tanpa tepi kosong. */
export const World: React.FC<{children?: React.ReactNode}> = ({children}) => (
  <svg width={1680} height={1920} viewBox="-300 0 1680 1920" style={{position: 'absolute', left: -300, top: 0, overflow: 'visible'}}>
    {children}
  </svg>
);
