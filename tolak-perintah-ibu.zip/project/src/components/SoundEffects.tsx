import React from 'react';
import {Audio, Sequence, interpolate, staticFile} from 'remotion';
import {HAS_NARASI, HAS_SOUND} from '../data/config';

type Sfx = {f: number; file: string; vol?: number};

/** Frame global (30fps). Volume SFX dijaga rendah agar tidak menutupi narasi. */
export const SFX: Sfx[] = [
  // Beat 01
  {f: 3, file: 'whoosh'}, {f: 22, file: 'frustration', vol: 0.3}, {f: 28, file: 'pop', vol: 0.3},
  {f: 62, file: 'pop', vol: 0.3}, {f: 96, file: 'pop', vol: 0.3}, {f: 216, file: 'impact', vol: 0.55},
  {f: 222, file: 'sting', vol: 0.4}, {f: 288, file: 'whoosh'},
  // Beat 02 (mulai 297)
  {f: 300, file: 'alarm', vol: 0.3}, {f: 372, file: 'bedsheet', vol: 0.5}, {f: 440, file: 'steps', vol: 0.35},
  {f: 457, file: 'pop', vol: 0.35}, {f: 512, file: 'pop', vol: 0.35}, {f: 587, file: 'pop', vol: 0.35},
  {f: 686, file: 'impact', vol: 0.4},
  // Beat 03 (mulai 714)
  {f: 744, file: 'sweep'}, {f: 804, file: 'refuse', vol: 0.4}, {f: 854, file: 'plates', vol: 0.4},
  {f: 899, file: 'refuse', vol: 0.4}, {f: 929, file: 'whoosh', vol: 0.3}, {f: 964, file: 'refuse', vol: 0.4},
  {f: 1034, file: 'bounce', vol: 0.5},
  // Beat 04 (mulai 1149)
  {f: 1209, file: 'plates', vol: 0.4}, {f: 1229, file: 'cloth', vol: 0.5}, {f: 1269, file: 'cloth', vol: 0.5},
  {f: 1479, file: 'sweat', vol: 0.5},
  // Beat 05 (mulai 1518)
  {f: 1538, file: 'growl', vol: 0.45}, {f: 1610, file: 'steps', vol: 0.3}, {f: 1623, file: 'pop', vol: 0.4},
  {f: 1748, file: 'sizzle', vol: 0.3}, {f: 1793, file: 'fire', vol: 0.35}, {f: 1818, file: 'whoosh', vol: 0.4},
  {f: 1858, file: 'plates', vol: 0.45}, {f: 1918, file: 'piano', vol: 0.4},
  // Beat 06 (mulai 2058)
  {f: 2068, file: 'steps', vol: 0.3}, {f: 2308, file: 'whoosh', vol: 0.4}, {f: 2358, file: 'paper', vol: 0.5},
  {f: 2388, file: 'paper', vol: 0.5}, {f: 2448, file: 'reveal', vol: 0.5}, {f: 2453, file: 'shock', vol: 0.5},
  {f: 2456, file: 'impact', vol: 0.55}, {f: 2463, file: 'sting', vol: 0.45},
];

const sfxLen = (file: string) => (file === 'alarm' || file === 'sizzle' ? 90 : file === 'piano' ? 100 : 60);

export const SoundEffects: React.FC = () => {
  if (!HAS_SOUND) return null;
  return (
    <>
      {SFX.map((s, i) => (
        <Sequence key={i} from={s.f} durationInFrames={sfxLen(s.file)}>
          <Audio src={staticFile(`sounds/${s.file}.wav`)} volume={s.vol ?? 0.4} />
        </Sequence>
      ))}
      {/* Musik latar: turun saat ibu diam (Beat 04), lebih cepat saat memasak (Beat 05), mereda di akhir */}
      <Sequence from={0} durationInFrames={1518}>
        <Audio src={staticFile('sounds/music.wav')} loop volume={(f: number) => interpolate(f, [0, 1330, 1380, 1500, 1518], [0.16, 0.16, 0.04, 0.04, 0.16], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'})} />
      </Sequence>
      <Sequence from={1518} durationInFrames={540}>
        <Audio src={staticFile('sounds/music.wav')} loop playbackRate={1.3} volume={0.18} />
      </Sequence>
      <Sequence from={2058} durationInFrames={492}>
        <Audio src={staticFile('sounds/music.wav')} loop volume={(f: number) => interpolate(f, [0, 380, 400, 492], [0.1, 0.1, 0.02, 0.02], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'})} />
      </Sequence>
    </>
  );
};

export const Narration: React.FC = () => (HAS_NARASI ? <Audio src={staticFile('narasi.mp3')} volume={1} /> : null);
