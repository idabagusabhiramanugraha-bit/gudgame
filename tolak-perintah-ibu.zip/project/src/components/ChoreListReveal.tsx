import React from 'react';
import {C} from '../data/config';

const ITEMS = [
  'Nyapu rumah', 'Ngepel lantai', 'Cuci piring', 'Cuci baju', 'Jemur baju', 'Setrika',
  'Masak', 'Bersihin kamar', 'Buang sampah', 'Belanja ke warung', 'Siram tanaman', 'Lipat baju',
  'Lap meja', 'Cuci kamar mandi', 'Dan seterusnya...',
];

/** Daftar pekerjaan memanjang dari tangan ibu. len = panjang yang terlihat, full = panjang penuh. */
export const ChoreList: React.FC<{x: number; y: number; w: number; len: number; full: number; sway?: number}> = ({x, y, w, len, full, sway = 0}) => {
  const rowH = 54;
  return (
    <g transform={`rotate(${sway} ${x} ${y})`}>
      <defs>
        <clipPath id="chore-clip">
          <rect x={x - w / 2 - 10} y={y - 10} width={w + 20} height={len + 10} />
        </clipPath>
      </defs>
      <g clipPath="url(#chore-clip)">
        <rect x={x - w / 2} y={y} width={w} height={full} fill="#FFFDF2" stroke={C.ink} strokeWidth={6} />
        <text x={x} y={y + 58} textAnchor="middle" fontSize={38} fontWeight={900} fontFamily="Arial Black, Arial, sans-serif" fill={C.ink}>
          DAFTAR PEKERJAAN
        </text>
        <text x={x} y={y + 104} textAnchor="middle" fontSize={38} fontWeight={900} fontFamily="Arial Black, Arial, sans-serif" fill={C.red}>
          SELAMA 1 BULAN!
        </text>
        <line x1={x - w / 2 + 20} y1={y + 124} x2={x + w / 2 - 20} y2={y + 124} stroke={C.ink} strokeWidth={4} />
        {ITEMS.map((t, i) => (
          <g key={i} transform={`translate(${x - w / 2 + 28} ${y + 160 + i * rowH})`}>
            <rect width={28} height={28} fill="none" stroke={C.ink} strokeWidth={4} />
            <text x={44} y={24} fontSize={28} fontWeight={700} fontFamily="'Comic Sans MS', 'Marker Felt', cursive" fill={C.ink}>
              {t}
            </text>
            <line x1={44} y1={34} x2={w - 70} y2={34} stroke="#C9C2A8" strokeWidth={2} />
          </g>
        ))}
      </g>
      <ellipse cx={x} cy={y + len} rx={w / 2} ry={14} fill="#EFE3BF" stroke={C.ink} strokeWidth={5} />
    </g>
  );
};

/** Bagian daftar yang tergeletak di lantai (perspektif) menuju anak. */
export const ChoreListTail: React.FC<{x: number; y: number; w: number; reach: number}> = ({x, y, w, reach}) => {
  const pts = `${x - w / 2},${y} ${x + w / 2},${y} ${x + w / 2 + 30},${y + 230} ${x - w / 2 - reach},${y + 230}`;
  return (
    <g>
      <polygon points={pts} fill="#FFFDF2" stroke={C.ink} strokeWidth={6} strokeLinejoin="round" />
      {[0.25, 0.5, 0.75].map((t) => (
        <line key={t} x1={x - w / 2 - (reach * t) + 0} y1={y + 230 * t} x2={x + w / 2 + 30 * t} y2={y + 230 * t} stroke="#C9C2A8" strokeWidth={4} />
      ))}
    </g>
  );
};
