import React from 'react';
import {Character, CharProps} from './Character';

/** Karakter anak: stickman kepala putih, rambut cokelat berdiri, hoodie abu. */
export const MainCharacter: React.FC<Omit<CharProps, 'who'>> = (props) => <Character who="kid" {...props} />;
