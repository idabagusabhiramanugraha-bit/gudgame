import React from 'react';
import {Easing, Sequence, interpolate, useCurrentFrame} from 'remotion';
import {C} from '../data/config';
import {LAYOUT, place} from '../data/layout';
import {CameraEffects, World} from '../components/CameraEffects';
import {MainCharacter} from '../components/MainCharacter';
import {MotherCharacter} from '../components/MotherCharacter';
import {POSES, Pose, handPos, mkPose, poseAt, walkPose} from '../components/Character';
import {LivingRoomBackground} from '../components/Backgrounds';
import {NightLighting} from '../components/Lighting';
import {ChoreList, ChoreListTail} from '../components/ChoreListReveal';
import {ImpactBurst, SpeedLines, Sparkle, Sunburst, Drop} from '../components/Effects';

const cl = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;
const back = Easing.out(Easing.back(1.5));

const kidP = place(LAYOUT.b06.kid);
const momP = place(LAYOUT.b06.mom);
const FLOOR = 1330;

const Night: React.FC<{children: React.ReactNode}> = ({children}) => (
  <>
    <LivingRoomBackground night />
    {children}
    <NightLighting glowX={1085} glowY={500} />
  </>
);

const RAISED: Pose = mkPose({aL: [42, -112], aR: [100, 60], lean: -3});
const momCommon = {who: 'mom' as const, ...momP};

/** S1: anak nyamperin ibu dan memohon. */
const Approach: React.FC = () => {
  const f = useCurrentFrame();
  const cx = interpolate(f, [0, 60], [-60, kidP.cx], {...cl, easing: Easing.out(Easing.cubic)});
  const pose = f < 62 ? walkPose(f, mkPose({aL: [14, 12], aR: [14, 12]})) : poseAt(f - 62, [{f: 0, pose: POSES.idle}, {f: 14, pose: POSES.plead}]);
  return (
    <CameraEffects keys={[{f: 0, s: 1, x: 0, y: 0}, {f: 190, s: 1.1, x: 30, y: -10}]}>
      <World>
        <Night>
          <MotherCharacter cx={momP.cx} cy={momP.cy} s={momP.s} pose={POSES.fold} expr="silent" frame={f} />
          <MainCharacter {...kidP} cx={cx} pose={pose} expr={f < 100 ? 'regretful' : 'crying'} frame={f} />
        </Night>
      </World>
    </CameraEffects>
  );
};

const MomSmile: React.FC = () => {
  const f = useCurrentFrame();
  return (
    <CameraEffects keys={[{f: 0, s: 1, x: 0, y: 0}, {f: 60, s: 1.08, x: 0, y: 0}]}>
      <World>
        <Night>
          <MotherCharacter cx={540} cy={1080} s={2} pose={POSES.fold} expr={f < 18 ? 'silent' : 'happy'} frame={f} />
          {f > 18 && <><Sparkle x={250} y={560} s={1.4} /><Sparkle x={860} y={470} s={1} /></>}
        </Night>
      </World>
    </CameraEffects>
  );
};

/** S3: quick zoom ke tangan ibu yang merogoh kertas. */
const PaperOut: React.FC = () => {
  const f = useCurrentFrame();
  const pose = poseAt(f, [{f: 0, pose: POSES.fold}, {f: 18, pose: mkPose({aL: [42, -112], aR: [62, -52], lean: -2})}]);
  const [hx, hy] = handPos({...momCommon, pose}, 'R');
  const z = interpolate(f, [0, 12], [1, 2.2], cl);
  return (
    <CameraEffects keys={[{f: 0, s: 1, x: 0, y: 0}, {f: 12, s: 2.2, x: -(hx - 540) * 2.2, y: -(hy - 960) * 2.2}, {f: 50, s: 2.2, x: -(hx - 540) * 2.2, y: -(hy - 960) * 2.2}]}>
      <World>
        <Night>
          <MotherCharacter cx={momP.cx} cy={momP.cy} s={momP.s} pose={pose} expr="happy" frame={f} />
          {f > 16 && <rect x={hx - 40} y={hy - 30} width={80} height={110} rx={6} fill="#FFFDF2" stroke={C.ink} strokeWidth={5} transform={`rotate(${f % 4} ${hx} ${hy})`} />}
        </Night>
      </World>
    </CameraEffects>
  );
};

const MOM_FIN = {...momCommon};

/** S4: kertas dibuka dan memanjang secara kartun; kamera tilt mengikuti. */
const Unroll: React.FC = () => {
  const f = useCurrentFrame();
  const pose = poseAt(f, [{f: 0, pose: mkPose({aL: [42, -112], aR: [62, -52]})}, {f: 14, pose: RAISED}]);
  const [hx, hy] = handPos({...MOM_FIN, pose}, 'R');
  const full = 640;
  const len = interpolate(f, [10, 60], [130, full], {...cl, easing: Easing.out(Easing.back(1.1))});
  const tail = interpolate(f, [55, 85], [0, 1], cl);
  return (
    <CameraEffects keys={[{f: 0, s: 1.3, x: -(hx - 540) * 1.3, y: -(hy - 960) * 1.3 + 40}, {f: 45, s: 1.15, x: -80, y: -150}, {f: 90, s: 1.06, x: 0, y: -40}]}>
      <World>
        <Night>
          <MainCharacter {...kidP} pose={mkPose({aL: [50, 50], aR: [50, 50]})} expr={f < 20 ? 'regretful' : f < 40 ? 'confused' : 'surprised'} frame={f} />
          <MotherCharacter cx={momP.cx} cy={momP.cy} s={momP.s} pose={pose} expr="happy" frame={f} />
          {tail > 0 && <ChoreListTail x={hx} y={Math.min(hy + full, FLOOR + 5)} w={380} reach={380 * tail} />}
          <ChoreList x={hx} y={hy} w={380} len={len} full={full} sway={Math.sin(f * 0.3) * 2 * (1 - tail)} />
        </Night>
      </World>
    </CameraEffects>
  );
};

/** S5: close-up kid syok (smash cut + impact). */
const Shock: React.FC = () => {
  const f = useCurrentFrame();
  return (
    <CameraEffects keys={[{f: 0, s: 1.15, x: 0, y: 0}, {f: 12, s: 1, x: 0, y: 0}, {f: 50, s: 1.06, x: 0, y: 0}]} shake={[{from: 0, to: 20, amp: 12}]}>
      <World>
        <Sunburst cx={540} cy={800} rot={f * 0.5} c1="#C62828" c2="#FF6B4A" n={20} />
        <SpeedLines cx={540} cy={760} frame={f} color="#3b0a0a" inner={380} />
        <MainCharacter cx={540} cy={1140} s={2} pose={mkPose({aL: [60, 50], aR: [60, 50]})} expr="shocked" frame={f < 30 ? f : 30} />
        <ImpactBurst x={540} y={420} frame={f} start={0} color={C.yellow} size={300} />
        <Drop x={820} y={520} frame={f} /><Drop x={230} y={600} frame={f + 9} />
      </World>
    </CameraEffects>
  );
};

/** S6: komposisi akhir. Ibu memegang daftar panjang, anak membeku lalu tergeletak. Tahan frame. */
const Final: React.FC = () => {
  const f = useCurrentFrame();
  const [hx, hy] = handPos({...MOM_FIN, pose: RAISED}, 'R');
  const fall = interpolate(f, [4, 20], [0, 1], {...cl, easing: Easing.out(Easing.back(1.3))});
  const kidRot = -88 * fall;
  const kidCy = 950 + (1215 - 950) * fall;
  const kidCx = kidP.cx + 150 * fall;
  const kidS = 1 - 0.15 * fall;
  const fr = Math.min(f, 20); // membeku: animasi berhenti
  return (
    <CameraEffects keys={[{f: 0, s: 1.08, x: 0, y: -35}, {f: 52, s: 1.05, x: 0, y: -25}]} shake={[{from: 0, to: 8, amp: 8}]}>
      <World>
        <Night>
          <ChoreListTail x={hx} y={FLOOR + 5} w={380} reach={380} />
          <MainCharacter {...kidP} s={kidS} cx={kidCx} cy={kidCy} rot={kidRot} pose={mkPose({aL: [60, 50], aR: [60, 50]})} expr="shocked" frame={fr} />
          <MotherCharacter cx={momP.cx} cy={momP.cy} s={momP.s} pose={RAISED} expr="happy" frame={fr} />
          <ChoreList x={hx} y={hy} w={380} len={640} full={640} />
          <Sparkle x={hx + 220} y={hy - 60} s={0.9} />
        </Night>
      </World>
    </CameraEffects>
  );
};

export const Beat06: React.FC = () => (
  <>
    <Sequence from={0} durationInFrames={190}><Approach /></Sequence>
    <Sequence from={190} durationInFrames={60}><MomSmile /></Sequence>
    <Sequence from={250} durationInFrames={50}><PaperOut /></Sequence>
    <Sequence from={300} durationInFrames={90}><Unroll /></Sequence>
    <Sequence from={390} durationInFrames={50}><Shock /></Sequence>
    <Sequence from={440} durationInFrames={52}><Final /></Sequence>
  </>
);
