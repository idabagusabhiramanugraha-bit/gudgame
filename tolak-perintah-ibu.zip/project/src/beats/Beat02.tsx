import React from 'react';
import {Easing, Sequence, interpolate, useCurrentFrame} from 'remotion';
import {C} from '../data/config';
import {LAYOUT, place} from '../data/layout';
import {CameraEffects, World} from '../components/CameraEffects';
import {MainCharacter} from '../components/MainCharacter';
import {MotherCharacter} from '../components/MotherCharacter';
import {POSES, mkPose} from '../components/Character';
import {BedScene} from '../components/Scenes';
import {BedroomBackground} from '../components/Backgrounds';
import {MorningLighting} from '../components/Lighting';
import {Bed, Bowl, Shower} from '../components/Props';
import {ImpactBurst, Sparkle, XMark} from '../components/Effects';

const cl = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;
const back = Easing.out(Easing.back(1.4));

const Shot1: React.FC = () => {
  const f = useCurrentFrame();
  return (
    <CameraEffects keys={[{f: 0, s: 1, x: 0, y: 0}, {f: 75, s: 1.12, x: 30, y: -60}]}>
      <World><BedScene frame={f} phase="shout" /></World>
    </CameraEffects>
  );
};

const Shot2: React.FC = () => {
  const f = useCurrentFrame();
  return (
    <CameraEffects keys={[{f: 0, s: 1.12, x: 60, y: -70}, {f: 85, s: 1.4, x: 80, y: -110}]} shake={[{from: 14, to: 24, amp: 8}]}>
      <World><BedScene frame={f} phase="shake" /></World>
    </CameraEffects>
  );
};

/** Tiga panel bertumpuk (split-screen) yang terbuka satu per satu mengikuti narasi. */
const Panel: React.FC<{i: number; start: number; frame: number; children: React.ReactNode; bg: string}> = ({i, start, frame, children, bg}) => {
  const t = frame - start;
  if (t < 0) return null;
  const w = interpolate(t, [0, 9], [0, 1000], {...cl, easing: back});
  const y = 220 + i * 372;
  const id = `panel-${i}`;
  return (
    <g>
      <defs><clipPath id={id}><rect x={40} y={y} width={w} height={360} rx={26} /></clipPath></defs>
      <g clipPath={`url(#${id})`}>
        <rect x={40} y={y} width={1000} height={360} fill={bg} />
        <g transform={`translate(0 ${y - 220 - i * 0})`}>{/* konten memakai y relatif panel 0..360 */}
          <g transform="translate(0 220)">{children}</g>
        </g>
      </g>
      <rect x={40} y={y} width={w} height={360} rx={26} fill="none" stroke={C.ink} strokeWidth={8} />
    </g>
  );
};

const Shot3: React.FC = () => {
  const f = useCurrentFrame();
  const s = 0.42;
  const cy = 180 + 12; // pusat karakter di dalam panel (relatif)
  return (
    <CameraEffects keys={[{f: 0, s: 1, x: 0, y: 0}, {f: 185, s: 1.04, x: 0, y: 0}]}>
      <World>
        <BedroomBackground />
        <MorningLighting />
        <rect x={-300} y={0} width={1680} height={1920} fill="#000" opacity={0.45} />
        {/* Panel 1: mandi */}
        <Panel i={0} start={0} frame={f} bg="#BFE3F2">
          <Shower x={150} y={330} s={1.2} frame={f} />
          <MainCharacter cx={420} cy={cy} s={s} pose={POSES.stop} expr="annoyed" frame={f} />
          <MotherCharacter cx={800} cy={cy} s={s} flip pose={POSES.point} expr="shouting" frame={f} />
          <XMark x={420} y={20} frame={f} start={26} s={0.8} />
        </Panel>
        {/* Panel 2: sarapan */}
        <Panel i={1} start={55} frame={f} bg="#F8E3B0">
          <rect x={60} y={250} width={240} height={26} fill="#B07B4F" stroke={C.ink} strokeWidth={5} />
          <Bowl x={170} y={252} s={1.3} />
          <MainCharacter cx={470} cy={cy} s={s} pose={mkPose({aL: [30, -100], aR: [85, 85], tilt: 10})} expr="ignoring" look={14} frame={f} />
          <MotherCharacter cx={820} cy={cy} s={s} flip pose={POSES.point} expr="angry" frame={f} />
          <XMark x={470} y={20} frame={f} start={55 + 26} s={0.8} />
        </Panel>
        {/* Panel 3: kasur ("Nanti!") */}
        <Panel i={2} start={130} frame={f} bg="#CDBFE6">
          <Bed x={80} y={320} s={0.5} layer="back" messy />
          <Bed x={80} y={320} s={0.5} layer="front" messy />
          <MainCharacter cx={510} cy={cy} s={s} flip pose={POSES.point} expr="smug" frame={f} />
          <MotherCharacter cx={840} cy={cy} s={s} flip pose={mkPose({aL: [42, -112], aR: [42, -112]})} expr="annoyed" frame={f} />
        </Panel>
      </World>
    </CameraEffects>
  );
};

/** Over-the-shoulder close-up: "Nanti!" santai dan sedikit sombong. */
const Shot4: React.FC = () => {
  const f = useCurrentFrame();
  const w = Math.sin(f * 0.55) * 18;
  const pose = mkPose({aL: [30, -110], aR: [80 + w, 20], lean: -3});
  return (
    <CameraEffects keys={[{f: 0, s: 1, x: 0, y: 0}, {f: 72, s: 1.15, x: 0, y: 0}]}>
      <World>
        <BedroomBackground />
        <MorningLighting />
        <MainCharacter cx={420} cy={1062} s={1.8} pose={pose} expr="smug" frame={f} />
        <MotherCharacter cx={930} cy={790} s={1.4} flip pose={mkPose({aL: [42, -112], aR: [42, -112]})} expr="annoyed" frame={f} />
        <Sparkle x={160} y={560} s={1.2} />
        <ImpactBurst x={800} y={400} frame={f} start={4} size={140} />
      </World>
    </CameraEffects>
  );
};

export const Beat02: React.FC = () => (
  <>
    <Sequence from={0} durationInFrames={75}><Shot1 /></Sequence>
    <Sequence from={75} durationInFrames={85}><Shot2 /></Sequence>
    <Sequence from={160} durationInFrames={185}><Shot3 /></Sequence>
    <Sequence from={345} durationInFrames={72}><Shot4 /></Sequence>
  </>
);
