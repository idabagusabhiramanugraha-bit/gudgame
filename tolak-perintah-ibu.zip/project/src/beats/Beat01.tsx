import React from 'react';
import {Easing, Sequence, interpolate, useCurrentFrame} from 'remotion';
import {C} from '../data/config';
import {LAYOUT, place} from '../data/layout';
import {CameraEffects, World} from '../components/CameraEffects';
import {MainCharacter} from '../components/MainCharacter';
import {MotherCharacter} from '../components/MotherCharacter';
import {POSES, mkPose, poseAt} from '../components/Character';
import {BedroomBackground} from '../components/Backgrounds';
import {DullLighting} from '../components/Lighting';
import {Broom, ThoughtBubble} from '../components/Props';
import {ImpactBurst, SpeedLines, Spiral, Sunburst} from '../components/Effects';

const back = Easing.out(Easing.back(1.7));
const cl = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;

/** S1: anak kesal, tiga bayangan ibu menyuruh ini itu. Push-in. */
const Shot1: React.FC = () => {
  const f = useCurrentFrame();
  const kid = place(LAYOUT.b01.kid);
  const bubbles: [number, number, number, number][] = [[40, 230, 28, 0], [720, 230, 62, 1], [380, 300, 96, 2]];
  return (
    <CameraEffects keys={[{f: 0, s: 1, x: 0, y: 0}, {f: 144, s: 1.35, x: 0, y: 180}]}>
      <World>
        <BedroomBackground />
        <DullLighting />
        {bubbles.map(([x, y, t0, i]) => {
          const k = interpolate(f - t0, [0, 9], [0, 1], {...cl, easing: back});
          if (f < t0) return null;
          const pose = [mkPose({aL: [60, -30], aR: [60, -30], lean: 6}), mkPose({aL: [42, -112], aR: [88, 4]}), mkPose({aL: [42, -112], aR: [70, -10]})][i];
          return (
            <g key={i} transform={`translate(0 ${Math.sin((f + i * 8) * 0.15) * 5})`}>
              <ThoughtBubble x={x + 160 * (1 - k)} y={y + 120 * (1 - k)} w={320} h={250} s={k} tail={[200, 330]}>
                <MotherCharacter cx={160} cy={125} s={0.3} pose={pose} expr={i === 2 ? 'annoyed' : 'shouting'} frame={f} holdR={i === 2 ? <Broom /> : undefined} upright={i === 2} />
              </ThoughtBubble>
            </g>
          );
        })}
        <MainCharacter {...kid} pose={poseAt(f, [{f: 0, pose: POSES.slump}, {f: 90, pose: mkPose({aL: [30, -120], aR: [30, -120], lean: 4})}])} expr={f < 70 ? 'annoyed' : 'angry'} frame={f} />
        {f > 20 && <Spiral x={330} y={640} frame={f} />}
      </World>
    </CameraEffects>
  );
};

/** S2: close-up muak. */
const Shot2: React.FC = () => {
  const f = useCurrentFrame();
  return (
    <CameraEffects keys={[{f: 0, s: 1, x: 0, y: 0}, {f: 72, s: 1.1, x: 0, y: 0}]}>
      <World>
        <BedroomBackground />
        <DullLighting />
        <MainCharacter cx={540} cy={1140} s={2} pose={mkPose({aL: [30, -120], aR: [30, -120]})} expr="angry" frame={f} />
        <Spiral x={880} y={470} frame={f} s={1.4} />
      </World>
    </CameraEffects>
  );
};

/** S3: smash cut ke sunburst, keputusan: menolak dengan kedua tangan. */
const Shot3: React.FC = () => {
  const f = useCurrentFrame();
  const wig = Math.sin(f * 0.9) * 10;
  const pose = poseAt(f, [
    {f: 0, pose: POSES.fold},
    {f: 14, pose: mkPose({aL: [150, -40], aR: [30, -120]})},
    {f: 34, pose: mkPose({aL: [85, 85], aR: [85, 85]})},
  ]);
  const p2 = f > 40 ? mkPose({aL: [85 + wig, 85], aR: [85 - wig, 85]}) : pose;
  return (
    <CameraEffects keys={[{f: 0, s: 1, x: 0, y: 0}, {f: 12, s: 1.25, x: 0, y: 20}, {f: 81, s: 1.3, x: 0, y: 20}]} shake={[{from: 0, to: 12, amp: 14}]}>
      <World>
        <Sunburst cx={540} cy={800} rot={f * 0.6} c1="#FFB84A" c2="#FFE08A" />
        <SpeedLines cx={540} cy={760} frame={f} color="#B45309" />
        <MainCharacter cx={540} cy={890} s={1.3} pose={p2} expr={f < 40 ? 'smug' : 'angry'} frame={f} />
        <ImpactBurst x={540} y={500} frame={f} start={0} />
      </World>
    </CameraEffects>
  );
};

export const Beat01: React.FC = () => (
  <>
    <Sequence from={0} durationInFrames={144}><Shot1 /></Sequence>
    <Sequence from={144} durationInFrames={72}><Shot2 /></Sequence>
    <Sequence from={216} durationInFrames={81}><Shot3 /></Sequence>
  </>
);
