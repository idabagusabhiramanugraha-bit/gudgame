import React from 'react';
import {Sequence, useCurrentFrame} from 'remotion';
import {CameraEffects, World} from '../components/CameraEffects';
import {CleaningScene, RefusalScene, SofaTriumph} from '../components/Scenes';

const Broom: React.FC = () => {
  const f = useCurrentFrame();
  return (
    <CameraEffects keys={[{f: 0, s: 1, x: 0, y: 0}, {f: 135, s: 1.1, x: -20, y: -20}]}>
      <World><CleaningScene frame={f} /></World>
    </CameraEffects>
  );
};

const Dishes: React.FC = () => {
  const f = useCurrentFrame();
  return (
    <CameraEffects keys={[{f: 0, s: 1.2, x: -80, y: 0}, {f: 80, s: 1.1, x: 0, y: 0}]}>
      <World><RefusalScene frame={f} kind="dishes" /></World>
    </CameraEffects>
  );
};

const Warung: React.FC = () => {
  const f = useCurrentFrame();
  return (
    <CameraEffects keys={[{f: 0, s: 1.15, x: 60, y: 0}, {f: 90, s: 1.05, x: 0, y: 0}]}>
      <World><RefusalScene frame={f} kind="warung" /></World>
    </CameraEffects>
  );
};

/** Wide shot anak di sofa, lalu slow push-in ke wajah penuh kemenangan. */
const Sofa: React.FC = () => {
  const f = useCurrentFrame();
  return (
    <CameraEffects keys={[{f: 0, s: 1, x: 0, y: 0}, {f: 50, s: 1, x: 0, y: 0}, {f: 130, s: 1.7, x: 0, y: 30}]}>
      <World><SofaTriumph frame={f} /></World>
    </CameraEffects>
  );
};

export const Beat03: React.FC = () => (
  <>
    <Sequence from={0} durationInFrames={135}><Broom /></Sequence>
    <Sequence from={135} durationInFrames={80}><Dishes /></Sequence>
    <Sequence from={215} durationInFrames={90}><Warung /></Sequence>
    <Sequence from={305} durationInFrames={130}><Sofa /></Sequence>
  </>
);
