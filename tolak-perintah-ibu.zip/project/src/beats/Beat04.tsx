import React from 'react';
import {Sequence, useCurrentFrame} from 'remotion';
import {C} from '../data/config';
import {CameraEffects, World} from '../components/CameraEffects';
import {MainCharacter} from '../components/MainCharacter';
import {MotherCharacter} from '../components/MotherCharacter';
import {POSES, mkPose} from '../components/Character';
import {LivingRoomBackground} from '../components/Backgrounds';
import {AfternoonLighting} from '../components/Lighting';
import {MessyHouseScene} from '../components/Scenes';
import {ClothesPile, SpeechBubble} from '../components/Props';
import {Drop} from '../components/Effects';

/** Wide establishing + pan menyapu kekacauan, lalu kembali ke ibu. */
const Wide: React.FC = () => {
  const f = useCurrentFrame();
  return (
    <CameraEffects
      keys={[
        {f: 0, s: 1, x: 0, y: 0},
        {f: 40, s: 1.25, x: -425, y: 0},
        {f: 100, s: 1.25, x: -200, y: 0},
        {f: 150, s: 1.25, x: 425, y: 0},
        {f: 205, s: 1.4, x: 224, y: -40},
      ]}
    >
      <World><MessyHouseScene frame={f} /></World>
    </CameraEffects>
  );
};

/** Close-up ibu diam. Bubble "..." tanpa teriak. */
const MomClose: React.FC = () => {
  const f = useCurrentFrame();
  const dots = f > 30;
  return (
    <CameraEffects keys={[{f: 0, s: 1, x: 0, y: 0}, {f: 80, s: 1.08, x: 0, y: 0}]}>
      <World>
        <LivingRoomBackground />
        <ClothesPile x={200} y={1500} n={5} />
        <AfternoonLighting />
        <MotherCharacter cx={540} cy={1080} s={2} pose={POSES.fold} expr="silent" frame={f} />
        {dots && (
          <SpeechBubble x={650} y={230} w={300} h={150} tailX={620} tailY={430}>
            {[0, 1, 2].map((i) => <circle key={i} cx={90 + i * 60} cy={75} r={13} fill={C.ink} />)}
          </SpeechBubble>
        )}
      </World>
    </CameraEffects>
  );
};

/** Close-up anak: mulai gelisah, melirik ibu, keringat. */
const KidClose: React.FC = () => {
  const f = useCurrentFrame();
  const look = f > 25 ? -14 : 0;
  return (
    <CameraEffects keys={[{f: 0, s: 1, x: 0, y: 0}, {f: 79, s: 1.12, x: 0, y: 0}]}>
      <World>
        <LivingRoomBackground />
        <AfternoonLighting />
        <MainCharacter cx={540} cy={1080} s={2} pose={mkPose({aL: [10, 12], aR: [10, 12]})} expr="nervous" look={look} frame={f} />
        {f > 30 && <Drop x={800} y={560} frame={f} />}
        <g stroke={C.ink} strokeWidth={6} fill="none" strokeLinecap="round" opacity={0.6}>
          <path d="M 220 520 q -14 -22 0 -44 q 14 -22 0 -44" />
          <path d="M 860 700 q 14 -22 0 -44" />
        </g>
      </World>
    </CameraEffects>
  );
};

export const Beat04: React.FC = () => (
  <>
    <Sequence from={0} durationInFrames={210}><Wide /></Sequence>
    <Sequence from={210} durationInFrames={80}><MomClose /></Sequence>
    <Sequence from={290} durationInFrames={79}><KidClose /></Sequence>
  </>
);
