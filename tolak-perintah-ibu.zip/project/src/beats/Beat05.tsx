import React from 'react';
import {Sequence, interpolate, useCurrentFrame} from 'remotion';
import {C} from '../data/config';
import {LAYOUT, place} from '../data/layout';
import {CameraEffects, World} from '../components/CameraEffects';
import {MainCharacter} from '../components/MainCharacter';
import {MotherCharacter} from '../components/MotherCharacter';
import {POSES, mkPose, walkPose} from '../components/Character';
import {KitchenBackground} from '../components/Backgrounds';
import {NightLighting} from '../components/Lighting';
import {CookingScene, MemoryScene} from '../components/Scenes';
import {Pan, SpeechBubble, ThoughtBubble} from '../components/Props';

const cl = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;
const Night: React.FC<{children: React.ReactNode}> = ({children}) => (
  <>
    <KitchenBackground night />
    {children}
    <NightLighting glowX={520} glowY={260} />
  </>
);

/** Lapar: pegang perut, bubble paha ayam, perut keroncongan. */
const Hungry: React.FC = () => {
  const f = useCurrentFrame();
  const kid = place(LAYOUT.b05.kid);
  const g = Math.sin(f * 1.3) * 3;
  return (
    <CameraEffects keys={[{f: 0, s: 1, x: 0, y: 0}, {f: 40, s: 1, x: 0, y: 0}, {f: 55, s: 1.45, x: 0, y: 0}, {f: 90, s: 1.1, x: 0, y: 0}]}>
      <World>
        <Night>
          <MainCharacter {...kid} pose={mkPose({aL: [24, -120], aR: [24, -120], lean: 8 + g})} expr="exhausted" frame={f} />
          <g stroke={C.ink} strokeWidth={6} fill="none" strokeLinecap="round" opacity={f > 25 ? 1 : 0}>
            <path d="M 420 1030 q -20 15 0 30" /><path d="M 660 1030 q 20 15 0 30" />
            <path d="M 400 1000 q -26 25 0 50" />
          </g>
          {f > 15 && (
            <ThoughtBubble x={620} y={250} w={320} h={230} tail={[560, 600]}>
              <ellipse cx={150} cy={105} rx={60} ry={42} fill="#D98A3D" stroke={C.ink} strokeWidth={6} transform="rotate(-25 150 105)" />
              <rect x={176} y={110} width={74} height={20} rx={10} fill="#fff" stroke={C.ink} strokeWidth={5} transform="rotate(-25 150 105)" />
            </ThoughtBubble>
          )}
        </Night>
      </World>
    </CameraEffects>
  );
};

/** Jalan ke dapur, buka lemari kosong, menoleh ke ibu. */
const Search: React.FC = () => {
  const f = useCurrentFrame();
  const cx = interpolate(f, [0, 45], [260, 540], cl);
  const pose = f < 45 ? walkPose(f, mkPose({aL: [14, 12], aR: [14, 12]})) : mkPose({aL: [14, 12], aR: [14, 12]});
  const open = interpolate(f, [30, 40], [0, 1], cl);
  return (
    <CameraEffects keys={[{f: 0, s: 1.1, x: 90, y: 0}, {f: 60, s: 1.1, x: -20, y: 0}]}>
      <World>
        <Night>
          <g>
            <rect x={600} y={170} width={190} height={230} fill="#2a1d14" stroke={C.ink} strokeWidth={6} />
            <path d={`M 600 170 L ${600 - 80 * open} ${190} L ${600 - 80 * open} ${390} L 600 400 Z`} fill="#C28F5E" stroke={C.ink} strokeWidth={5} />
          </g>
          <MotherCharacter cx={900} cy={980} s={1} flip pose={POSES.fold} expr="silent" frame={f} />
          <MainCharacter cx={cx} cy={960} s={1} flip={f > 48} pose={pose} expr={f < 35 ? 'lazy' : 'confused'} frame={f} />
        </Night>
      </World>
    </CameraEffects>
  );
};

/** "Masak sendiri, kan udah gede!" dua-shot lalu close-up ibu. */
const Mom: React.FC = () => {
  const f = useCurrentFrame();
  return (
    <CameraEffects keys={[{f: 0, s: 1, x: 0, y: 0}, {f: 25, s: 1, x: 0, y: 0}, {f: 45, s: 1.5, x: -330, y: -70}]}>
      <World>
        <Night>
          <MainCharacter cx={330} cy={960} s={1} pose={mkPose({aL: [14, 12], aR: [14, 12], tilt: -6})} expr="confused" frame={f} />
          <MotherCharacter cx={770} cy={950} s={1} flip pose={POSES.point} expr="smug" frame={f} />
          <SpeechBubble x={470} y={230} w={230} h={170} tailX={640} tailY={560}>
            <g transform="translate(115 70) scale(0.5) rotate(0)">
              <Pan tilt={-90} />
            </g>
          </SpeechBubble>
        </Night>
      </World>
    </CameraEffects>
  );
};

const Cook: React.FC = () => {
  const f = useCurrentFrame();
  return (
    <CameraEffects
      keys={[{f: 0, s: 1, x: 0, y: 0}, {f: 60, s: 1.12, x: -30, y: 10}, {f: 120, s: 1.05, x: 20, y: -10}, {f: 175, s: 1.15, x: 0, y: 0}]}
      shake={[{from: 30, to: 170, amp: 7}]}
    >
      <World><CookingScene frame={f} /></World>
    </CameraEffects>
  );
};

const Memory: React.FC = () => {
  const f = useCurrentFrame();
  return (
    <CameraEffects keys={[{f: 0, s: 1, x: 0, y: 0}, {f: 150, s: 1.12, x: 0, y: 30}]}>
      <World><MemoryScene frame={f} /></World>
    </CameraEffects>
  );
};

export const Beat05: React.FC = () => (
  <>
    <Sequence from={0} durationInFrames={90}><Hungry /></Sequence>
    <Sequence from={90} durationInFrames={60}><Search /></Sequence>
    <Sequence from={150} durationInFrames={65}><Mom /></Sequence>
    <Sequence from={215} durationInFrames={175}><Cook /></Sequence>
    <Sequence from={390} durationInFrames={150}><Memory /></Sequence>
  </>
);
