import React from 'react';
import {AbsoluteFill, Sequence} from 'remotion';
import {BEATS} from './data/beats';
import {Beat01} from './beats/Beat01';
import {Beat02} from './beats/Beat02';
import {Beat03} from './beats/Beat03';
import {Beat04} from './beats/Beat04';
import {Beat05} from './beats/Beat05';
import {Beat06} from './beats/Beat06';
import {Subtitle} from './components/Subtitle';
import {Narration, SoundEffects} from './components/SoundEffects';

const COMPS = [Beat01, Beat02, Beat03, Beat04, Beat05, Beat06];

/** Tanpa header/judul/nomor scene: hanya adegan + subtitle bawah. */
export const Video: React.FC = () => (
  <AbsoluteFill style={{backgroundColor: '#000'}}>
    {BEATS.map((b, i) => {
      const Comp = COMPS[i];
      return (
        <Sequence key={b.id} from={b.from} durationInFrames={b.dur} name={b.key}>
          <Comp />
        </Sequence>
      );
    })}
    <Subtitle />
    <Narration />
    <SoundEffects />
  </AbsoluteFill>
);
