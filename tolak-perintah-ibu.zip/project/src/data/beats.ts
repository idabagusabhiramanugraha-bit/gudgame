export type Beat = {id: number; key: string; from: number; dur: number};

/** Timing PERKIRAAN dari SRT (belum tersinkron dengan audio asli). */
export const BEATS: Beat[] = [
  {id: 1, key: 'hook', from: 0, dur: 297},
  {id: 2, key: 'pagi', from: 297, dur: 417},
  {id: 3, key: 'siang', from: 714, dur: 435},
  {id: 4, key: 'sore', from: 1149, dur: 369},
  {id: 5, key: 'malam', from: 1518, dur: 540},
  {id: 6, key: 'ending', from: 2058, dur: 492},
];
