import {FPS, toFrame} from './config';

/**
 * Subtitle PROVISIONAL: timing berasal dari SRT (perkiraan), BELUM disinkronkan dengan
 * narasi.mp3 asli. Setelah audio dipasang, sesuaikan AUDIO_OFFSET di config.ts.
 */
type Cue = {s: number; e: number; t: string};

export const CUES: Cue[] = [
  {s: 0.12, e: 4.8, t: 'Pernah enggak sih kamu capek banget karena ibu selalu nyuruh ini itu? Sampai'},
  {s: 4.8, e: 9.22, t: 'akhirnya kamu memutuskan hari ini kamu enggak bakal nurut sama sekali.'},
  {s: 9.94, e: 14.82, t: 'Jam 6 pagi, ibu udah teriak nyuruh bangun, tapi kamu malah narik selimut dan'},
  {s: 14.82, e: 19.52, t: 'pura-pura enggak denger. Disuruh mandi, enggak mau. Disuruh sarapan, enggak laper.'},
  {s: 19.52, e: 23.44, t: 'Bahkan disuruh beresin kasur aja, kamu langsung bilang, "Nanti."'},
  {s: 24.14, e: 28.92, t: 'Siangnya, ibu nyuruh kamu nyapu rumah. Kamu jawab, "Enggak mau." Disuruh cuci'},
  {s: 28.92, e: 34.22, t: 'piring, "Ogah." Disuruh beli sesuatu ke warung, "Males banget." Rasanya enak'},
  {s: 34.22, e: 39.32, t: 'banget bisa nolak semua perintah tanpa ada yang bisa ngatur kamu. Tapi lama-lama,'},
  {s: 39.32, e: 44.3, t: 'rumah mulai kelihatan kayak kapal pecah. Piring numpuk, baju kotor berserakan,'},
  {s: 44.3, e: 49.5, t: 'kamar berantakan. Ibu pun mulai diam. Enggak marah, enggak ngomel, cuma'},
  {s: 49.5, e: 50.28, t: 'ngeliatin kamu.'},
  {s: 50.9, e: 55.76, t: 'Malamnya, kamu mulai kelaparan dan nyari makanan. Tapi ibu cuma bilang, "Masak'},
  {s: 55.76, e: 57.12, t: 'sendiri, kan udah gede."'},
  {s: 57.72, e: 62.84, t: 'Akhirnya kamu coba masak, tapi dapur malah hampir jadi tempat bencana. Kamu baru'},
  {s: 62.84, e: 68.08, t: 'sadar, ternyata selama ini ibu ngurusin banyak banget hal yang enggak pernah kamu'},
  {s: 68.08, e: 74.18, t: 'pikirin. Akhirnya kamu nyamperin ibu dan bilang, "Bu, aku nyerah. Besok aku bakal'},
  {s: 74.18, e: 79.3, t: 'nurut sama semua perintah ibu." Ibu tersenyum, lalu tiba-tiba mengeluarkan'},
  {s: 79.3, e: 83.66, t: 'selembar kertas. Ternyata itu daftar pekerjaan selama sebulan.'},
];

export type CapWord = {text: string; hi: boolean; start: number; end: number};
export type Caption = {start: number; end: number; lines: CapWord[][]};

const HI = new Set([
  'capek', 'nurut', 'sekali', 'pagi', 'selimut', 'nanti', 'mau', 'laper', 'ogah', 'males', 'banget',
  'kapal', 'pecah', 'diam', 'kelaparan', 'masak', 'bencana', 'sadar', 'nyerah', 'daftar', 'pekerjaan', 'sebulan', '6',
]);
const MAX_CHARS = 22;
const norm = (w: string) => w.toLowerCase().replace(/[^a-z0-9]/g, '');

/** Bagi durasi tiap cue ke kata secara proporsional jumlah karakter. */
const allWords = (): CapWord[] => {
  const out: CapWord[] = [];
  for (const c of CUES) {
    const ws = c.t.split(/\s+/);
    const total = ws.reduce((a, w) => a + w.length + 1, 0);
    let t = c.s;
    for (const w of ws) {
      const d = ((w.length + 1) / total) * (c.e - c.s);
      out.push({text: w, hi: HI.has(norm(w)), start: t, end: t + d});
      t += d;
    }
  }
  return out;
};

const build = (): Caption[] => {
  const words = allWords();
  const chunks: CapWord[][] = [];
  let cur: CapWord[] = [];
  const fits = (ws: CapWord[]) => {
    let lines = 1;
    let len = 0;
    for (const w of ws) {
      const add = (len ? 1 : 0) + w.text.length;
      if (len + add > MAX_CHARS) {
        lines++;
        len = w.text.length;
      } else len += add;
    }
    return lines <= 2;
  };
  words.forEach((w, i) => {
    if (cur.length && !fits([...cur, w])) {
      chunks.push(cur);
      cur = [];
    }
    cur.push(w);
    const last = /[.?!]["']?$/.test(w.text);
    if (last || i === words.length - 1) {
      chunks.push(cur);
      cur = [];
    }
  });
  if (cur.length) chunks.push(cur);

  return chunks.map((ws, i) => {
    const lines: CapWord[][] = [[]];
    let len = 0;
    for (const w of ws) {
      const add = (len ? 1 : 0) + w.text.length;
      if (len + add > MAX_CHARS && lines[lines.length - 1].length) {
        lines.push([]);
        len = 0;
      }
      lines[lines.length - 1].push(w);
      len += (len ? 1 : 0) + w.text.length;
    }
    const startT = ws[0].start;
    const endT = ws[ws.length - 1].end;
    const nextStart = chunks[i + 1] ? chunks[i + 1][0].start : endT + 0.4;
    const holdEnd = nextStart - endT < 0.45 ? nextStart : endT + 0.25;
    return {start: toFrame(startT), end: Math.max(toFrame(holdEnd), toFrame(startT) + 8), lines};
  });
};

export const CAPTIONS: Caption[] = build();
export const SRT_FPS = FPS;
