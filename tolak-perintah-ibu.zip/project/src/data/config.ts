export const FPS = 30;
export const WIDTH = 1080;
export const HEIGHT = 1920;
/** 85.0 detik: narasi (SRT berakhir 83,66 dtk) + tahan frame terakhir. */
export const TOTAL_FRAMES = 2550;

/** Geser subtitle (detik). Atur setelah narasi.mp3 asli dipasang. */
export const AUDIO_OFFSET = 0;
/** Ubah ke true setelah public/narasi.mp3 tersedia. Tanpa file, render akan gagal. */
export const HAS_NARASI = false;
/** Musik latar + SFX sintetis (public/sounds). */
export const HAS_SOUND = true;

export const toFrame = (t: number) => Math.round((t + AUDIO_OFFSET) * FPS);

export const C = {
  ink: '#111111',
  hair: '#4A2C1A',
  hairHi: '#7A5232',
  hoodie: '#D9DCE3',
  hoodieDark: '#B4B9C4',
  blouse: '#E8D5B7',
  apron: '#6E2A2A',
  apronDark: '#4F1D1D',
  yellow: '#FFD93B',
  red: '#E5383B',
  wood: '#B07B4F',
  woodDark: '#8A5A36',
  white: '#FFFFFF',
} as const;
