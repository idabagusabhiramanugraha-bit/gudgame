export type Rect = {x: number; y: number; w: number; h: number};

/** Zona subtitle (kanvas 1080x1920). Karakter berada di atas y=1340. */
export const SUBTITLE: Rect = {x: 90, y: 1400, w: 900, h: 190};

export const LAYOUT = {
  b01: {
    kid: {x: 140, y: 500, w: 800, h: 830},
    kidClose: {x: 90, y: 360, w: 900, h: 960},
    bubbles: {x: 60, y: 200, w: 960, h: 420},
  },
  b02: {
    clock: {x: 790, y: 798, w: 165, h: 102},
    kidSleep: {x: 80, y: 880, w: 620, h: 440},
    mom: {x: 600, y: 420, w: 420, h: 880},
    split: {x: 40, y: 220, w: 1000, h: 1100},
  },
  b03: {
    mom: {x: 40, y: 560, w: 460, h: 780},
    kid: {x: 580, y: 560, w: 440, h: 780},
    sofaKid: {x: 240, y: 800, w: 740, h: 540},
  },
  b04: {
    wide: {x: 0, y: 300, w: 1080, h: 1040},
    momClose: {x: 160, y: 380, w: 760, h: 800},
  },
  b05: {
    kid: {x: 300, y: 560, w: 480, h: 780},
    mom: {x: 700, y: 420, w: 340, h: 900},
    pan: {x: 520, y: 980, w: 440, h: 260},
    memory: {x: 60, y: 240, w: 960, h: 700},
  },
  b06: {
    kid: {x: 20, y: 570, w: 440, h: 760},
    mom: {x: 380, y: 520, w: 440, h: 820},
    paperStart: {x: 560, y: 860, w: 220, h: 160},
    list: {x: 640, y: 750, w: 380, h: 640},
  },
} as const;

/** Pusat dan skala karakter (tinggi native 760) untuk sebuah rect. */
export const place = (r: Rect, mode: 'stand' | 'lying' = 'stand') => ({
  cx: r.x + r.w / 2,
  cy: r.y + r.h / 2,
  s: mode === 'lying' ? r.w / 760 : r.h / 760,
});
